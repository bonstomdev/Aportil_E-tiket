<?php
require_once 'config.php';
require_once 'wa_helper.php';
checkAuth(); 

$msg = '';
$wa_link = '';

if (isset($_GET['approve'])) {
    $id = (int)$_GET['approve'];
    $q_data = $mysqli->query("SELECT nama_pemesan, no_hp, total_bayar, kode_booking FROM booking WHERE id = $id")->fetch_assoc();
    
    $stmt = $mysqli->prepare("UPDATE booking SET status = 'Paid' WHERE id = ?");
    $stmt->bind_param('i', $id);
    
    if ($stmt->execute()) {
        $msg = "<div class='alert-success'>✅ Pembayaran berhasil divalidasi! Status berubah menjadi PAID.</div>";
        catatLog("Validasi Tiket", "Tiket " . $q_data['kode_booking'] . " divalidasi");
        if ($q_data) {
            $pesan_wa = getWhatsAppMessage($q_data['nama_pemesan'], $q_data['kode_booking'], $q_data['total_bayar']);
            $no_hp_clean = preg_replace('/[^0-9]/', '', $q_data['no_hp']);
            if (substr($no_hp_clean, 0, 1) == '0') { $no_hp_clean = '670' . substr($no_hp_clean, 1); }
            $wa_link = "https://wa.me/" . $no_hp_clean . "?text=" . urlencode($pesan_wa);
        }
    }
    $stmt->close();
}

if (isset($_GET['batal'])) {
    $id = (int)$_GET['batal'];
    $stmt = $mysqli->prepare("UPDATE booking SET status = 'Cancelled' WHERE id = ?");
    $stmt->bind_param('i', $id);
    if ($stmt->execute()) {
        $msg = "<div class='alert-error'>🗑️ Pesanan telah dibatalkan.</div>";
    }
    $stmt->close();
}

$sql = "SELECT b.*, v.kode_voyage, v.tanggal, v.jam_berangkat, k.nama_kapal, p1.nama as asal, p2.nama as tujuan, 
        GROUP_CONCAT(t.nama_penumpang SEPARATOR ', ') as list_penumpang, 
        COUNT(t.id) as total_pax,
        MAX(t.kelas) as kelas, MAX(t.jenis_kendaraan) as jenis_kendaraan, MAX(t.jumlah_kargo) as jumlah_kargo
        FROM booking b
        JOIN voyage v ON b.voyage_id = v.id
        JOIN kapal k ON v.kapal_id = k.id
        JOIN pelabuhan p1 ON v.pelabuhan_asal_id = p1.id
        JOIN pelabuhan p2 ON v.pelabuhan_tujuan_id = p2.id
        JOIN tiket t ON t.booking_id = b.id
        GROUP BY b.id
        ORDER BY b.status ASC, b.id DESC";
$result = $mysqli->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi Tiket - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= ucfirst($_SESSION['role'] ?? 'kasir') ?>)</span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <?php if(($_SESSION['role'] ?? '') == 'admin'): ?>
                <a href="kapal.php">⚓ Master Pelabuhan
            <a href="kapal.php">🚢 Master Kapal</a></a>
                <a href="rute.php">🗺️ Master Rute</a>
                <a href="voyage.php">⏰ Jadwal Voyage</a>
            <?php endif; ?>
            <a href="verifikasi.php" class="active">📥 Verifikasi Tiket</a>
            <a href="scan.php">📷 Scan QR</a>
            <?php if(($_SESSION['role'] ?? '') == 'admin'): ?>
                <a href="laporan.php">📑 Laporan</a>
                <a href="z_report.php">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a></a>
                <a href="profil.php">🏢 Profil Perusahaan</a>
                <a href="users.php">👥 Manajemen Pegawai</a>
                <a href="log.php">🕵️‍♂️ Log Aktivitas</a>
                <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
                <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
            <?php endif; ?>
        </div>

        <div class="main-content">
            <h2>Verifikasi Pembayaran</h2>
            <p>Daftar pesanan penumpang. Lihat bukti transfer lalu validasi jika uang sudah masuk.</p>
            
            <?= $msg ?>

            <?php if ($wa_link): ?>
                <div class="alert-success" style="text-align: center; background: #dcfce7; border-color: #86efac; margin-bottom: 20px;">
                    <p style="margin-bottom: 10px; font-size: 16px;"><b>Tiket berhasil divalidasi!</b> Klik tombol di bawah untuk mengirim E-Ticket ke WhatsApp:</p>
                    <a href="<?= $wa_link ?>" target="_blank" class="btn-primary" style="background: #25D366; text-decoration: none; display: inline-block; width: auto; padding: 12px 25px;">💬 Kirim Pesan WA Sekarang</a>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Kode Booking / Tgl</th>
                                <th>Data Penumpang</th>
                                <th>Jadwal</th>
                                <th>Total & Bukti</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <b><?= htmlspecialchars($row['kode_booking']) ?></b><br>
                                        <small style="color:#666;"><?= date('d/m/y H:i', strtotime($row['created_at'])) ?></small>
                                    </td>
                                    <td>
                                        <b><?= $row['total_pax'] ?> Orang</b><br>
                                        <small><?= htmlspecialchars($row['list_penumpang']) ?></small><br>
                                        <small>Kelas: <?= $row['kelas'] ?></small>
                                    </td>
                                    <td>
                                        <b><?= $row['kode_voyage'] ?></b> - <?= htmlspecialchars($row['nama_kapal']) ?><br>
                                        <small><?= date('d M Y', strtotime($row['tanggal'])) ?> | <?= date('H:i', strtotime($row['jam_berangkat'])) ?></small>
                                    </td>
                                    <td>
                                        <b>$<?= number_format($row['total_bayar'], 2) ?></b><br>
                                        <?php if($row['status'] == 'Pending'): ?>
                                            <span style="background: #fff3e0; color: #e65100; padding: 2px 6px; border-radius: 4px; font-size: 12px; font-weight: bold;">⏳ PENDING</span><br>
                                            
                                            <?php if($row['bukti_transfer']): ?>
                                                <a href="uploads/<?= htmlspecialchars($row['bukti_transfer']) ?>" target="_blank" style="display:inline-block; margin-top:5px; font-size:12px; color:#0B2E6F; font-weight:bold; text-decoration:underline;">🖼️ Lihat Bukti TF</a>
                                            <?php else: ?>
                                                <small style="color:#999; font-size:11px;">Belum upload bukti</small>
                                            <?php endif; ?>

                                        <?php elseif($row['status'] == 'Paid'): ?>
                                            <span style="background: #e8f5e9; color: #2e7d32; padding: 2px 6px; border-radius: 4px; font-size: 12px; font-weight: bold;">✅ PAID</span>
                                        <?php else: ?>
                                            <span style="background: #ffebee; color: #d32f2f; padding: 2px 6px; border-radius: 4px; font-size: 12px; font-weight: bold;">❌ CANCELLED</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="white-space: nowrap;">
                                        <a href="detail_penumpang.php?id=<?= $row['id'] ?>" target="_blank" class="btn-primary" style="background: #6a1b9a; padding: 6px 12px; font-size: 12px; display: inline-block; width: auto; text-decoration: none; margin-bottom: 5px;">👁️ Lihat Foto ID</a>

                                        <?php if($row['status'] == 'Pending'): ?>
                                            <a href="?approve=<?= $row['id'] ?>" class="btn-primary" style="padding: 6px 12px; font-size: 12px; display: inline-block; width: auto; margin-bottom: 5px;" onclick="return confirm('Validasi pembayaran ini?')">✅ Validasi</a>
                                            <a href="?batal=<?= $row['id'] ?>" class="btn-danger" onclick="return confirm('Batalkan pesanan ini?')">Batal</a>
                                        <?php elseif($row['status'] == 'Paid'): ?>
                                            <a href="tiket.php?kode=<?= $row['kode_booking'] ?>" target="_blank" class="btn-primary" style="background: #0d47a1; padding: 6px 12px; font-size: 12px; display: inline-block; width: auto; text-decoration: none; margin-bottom: 5px;">🖨️ E-Ticket</a>
                                            <a href="reschedule.php?id=<?= $row['id'] ?>" class="btn-primary" style="background: #e65100; padding: 6px 12px; font-size: 12px; display: inline-block; width: auto; text-decoration: none; margin-bottom: 5px;">🔄 Reschedule</a>
                                            <a href="<?= 'https://wa.me/' . preg_replace('/[^0-9]/', '', $row['no_hp']) . '?text=' . urlencode(getWhatsAppMessage($row['nama_pemesan'], $row['kode_booking'], $row['total_bayar'])) ?>" target="_blank" class="btn-primary" style="background: #25D366; padding: 6px 12px; font-size: 12px; display: inline-block; width: auto; text-decoration: none;">💬 Kirim WA</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" style="text-align:center;">Belum ada pesanan masuk.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
