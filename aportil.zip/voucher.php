<?php
require_once 'config.php';
checkAuth();
checkAdmin();

$msg = '';

// Proses Tambah Voucher
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    verifyCsrfToken($_POST['csrf_token']);
    $kode = strtoupper(trim($_POST['kode']));
    $tipe = $_POST['tipe'];
    $nilai = (float)$_POST['nilai'];
    $kuota = (int)$_POST['kuota'];

    if ($kode !== '' && $nilai > 0) {
        $stmt = $mysqli->prepare("INSERT INTO voucher (kode, tipe, nilai, kuota) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('ssdi', $kode, $tipe, $nilai, $kuota);
        if ($stmt->execute()) {
            $msg = "<div class='alert-success'>✅ Voucher <b>$kode</b> berhasil dibuat!</div>";
            catatLog("Buat Voucher", "Kode: $kode");
        } else {
            $msg = "<div class='alert-error'>❌ Kode voucher sudah ada / gagal disimpan.</div>";
        }
        $stmt->close();
    }
}

// Proses Hapus Voucher
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $stmt = $mysqli->prepare("DELETE FROM voucher WHERE id = ?");
    $stmt->bind_param('i', $id);
    if ($stmt->execute()) {
        $msg = "<div class='alert-error'>🗑️ Voucher berhasil dihapus!</div>";
    }
    $stmt->close();
}

$result = $mysqli->query("SELECT * FROM voucher ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voucher Promo - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= ucfirst($_SESSION['role']) ?>)</span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="kapal.php">⚓ Master Pelabuhan
            <a href="kapal.php">🚢 Master Kapal</a></a>
            <a href="rute.php">🗺️ Master Rute</a>
            <a href="voyage.php">⏰ Jadwal Voyage</a>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <a href="laporan.php">📑 Laporan</a>
            <a href="z_report.php">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a></a>
            <a href="voucher.php" class="active">🎟️ Voucher Promo</a>
            <a href="profil.php">🏢 Profil Perusahaan</a>
            <a href="users.php">👥 Manajemen Pegawai</a>
            <a href="log.php">🕵️‍♂️ Log Aktivitas</a>
            <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
            <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
        </div>

        <div class="main-content">
            <h2>Manajemen Voucher</h2>
            <p>Buat kode promo untuk memberikan diskon kepada penumpang.</p>
            
            <?= $msg ?>

            <div class="card" style="max-width: 600px;">
                <h3>Buat Voucher Baru</h3>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Kode Voucher (Tanpa Spasi)</label>
                            <input type="text" name="kode" placeholder="Misal: PROMOAKHIRTAHUN" required style="text-transform: uppercase;">
                        </div>
                        <div class="form-group">
                            <label>Tipe Diskon</label>
                            <select name="tipe" required>
                                <option value="nominal">Nominal ($ USD)</option>
                                <option value="persen">Persentase (%)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Nilai Diskon</label>
                            <input type="number" step="0.01" name="nilai" placeholder="Misal: 2 atau 10" required>
                        </div>
                        <div class="form-group">
                            <label>Kuota (Isi 0 jika tanpa batas)</label>
                            <input type="number" name="kuota" value="0" required>
                        </div>
                    </div>
                    <button type="submit" name="tambah" class="btn-primary">+ Buat Voucher</button>
                </form>
            </div>

            <div class="card" style="margin-top: 20px;">
                <h3>Daftar Voucher</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Tipe & Nilai</th>
                                <th>Kuota / Terpakai</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><b style="font-family: monospace; font-size: 14px; background: #eee; padding: 2px 6px; border-radius: 4px;"><?= htmlspecialchars($row['kode']) ?></b></td>
                                    <td><?= $row['tipe'] == 'nominal' ? '$'.number_format($row['nilai'],2) : $row['nilai'].'%' ?></td>
                                    <td><?= $row['kuota'] == 0 ? 'Tanpa Batas' : $row['kuota'] ?> / <?= $row['terpakai'] ?></td>
                                    <td><span style="color: <?= $row['status'] == 'aktif' ? 'green' : 'red' ?>; font-weight: bold;"><?= strtoupper($row['status']) ?></span></td>
                                    <td><a href="?hapus=<?= $row['id'] ?>" class="btn-danger" onclick="return confirm('Hapus voucher ini?')">Hapus</a></td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" style="text-align:center;">Belum ada voucher.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
