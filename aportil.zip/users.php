<?php
require_once 'config.php';
checkAuth();
checkAdmin(); // Hanya Admin yang boleh masuk

$msg = '';

// Proses Tambah User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    verifyCsrfToken($_POST['csrf_token']);
    $u = trim($_POST['username']);
    $p = $_POST['password'];
    $r = $_POST['role'];

    if (strlen($u) < 4 || strlen($p) < 6) {
        $msg = "<div class='alert-error'>❌ Username min. 4 karakter, Password min. 6 karakter!</div>";
    } else {
        $cek = $mysqli->prepare("SELECT id FROM users WHERE username = ?");
        $cek->bind_param('s', $u);
        $cek->execute();
        if ($cek->get_result()->num_rows > 0) {
            $msg = "<div class='alert-error'>❌ Username sudah digunakan!</div>";
        } else {
            $hash = password_hash($p, PASSWORD_DEFAULT);
            $stmt = $mysqli->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
            $stmt->bind_param('sss', $u, $hash, $r);
            if ($stmt->execute()) {
                $msg = "<div class='alert-success'>✅ Akun <b>$u</b> berhasil dibuat!</div>";
            }
            $stmt->close();
        }
        $cek->close();
    }
}

// Proses Hapus User
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    if ($id == 1 || $id == $_SESSION['user_id']) {
        $msg = "<div class='alert-error'>❌ Tidak bisa menghapus akun utama atau akun Anda sendiri!</div>";
    } else {
        $stmt = $mysqli->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) {
            $msg = "<div class='alert-error'>🗑️ Akun berhasil dihapus!</div>";
        }
        $stmt->close();
    }
}

$result = $mysqli->query("SELECT * FROM users ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Pegawai - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= ucfirst($_SESSION['role']) ?>)</span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <?php if($_SESSION['role'] == 'admin'): ?>
                <a href="kapal.php">⚓ Master Pelabuhan
            <a href="kapal.php">🚢 Master Kapal</a></a>
                <a href="rute.php">🗺️ Master Rute</a>
                <a href="voyage.php">⏰ Jadwal Voyage</a>
            <?php endif; ?>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <?php if($_SESSION['role'] == 'admin'): ?>
                <a href="laporan.php">📑 Laporan</a>
                <a href="z_report.php">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a></a>
                <a href="profil.php">🏢 Profil Perusahaan</a>
                <a href="users.php" class="active">👥 Manajemen Pegawai
            <a href="log.php">🕵️‍♂️ Log Aktivitas</a></a>
                <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
                <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
            <?php endif; ?>
        </div>

        <div class="main-content">
            <h2>Manajemen Pegawai</h2>
            <p>Kelola akun untuk Admin dan Kasir.</p>
            
            <?= $msg ?>

            <div class="card" style="max-width: 500px;">
                <h3>Tambah Akun Baru</h3>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" required minlength="4" placeholder="Min. 4 karakter">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" required minlength="6" placeholder="Min. 6 karakter">
                    </div>
                    <div class="form-group">
                        <label>Role / Hak Akses</label>
                        <select name="role" required>
                            <option value="kasir">Kasir / Petugas Loket</option>
                            <option value="admin">Admin Penuh</option>
                        </select>
                    </div>
                    <button type="submit" name="tambah" class="btn-primary">+ Tambah Akun</button>
                </form>
            </div>

            <div class="card" style="margin-top: 20px;">
                <h3>Daftar Akun</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Username</th>
                                <th>Role</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no=1; while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><b><?= htmlspecialchars($row['username']) ?></b> <?= $row['id'] == $_SESSION['user_id'] ? '(Anda)' : '' ?></td>
                                <td>
                                    <span style="background: <?= $row['role'] == 'admin' ? '#e8f5e9' : '#e0e7ff' ?>; color: <?= $row['role'] == 'admin' ? '#2e7d32' : '#1e40af' ?>; padding: 2px 6px; border-radius: 4px; font-size: 12px; font-weight: bold;">
                                        <?= ucfirst($row['role']) ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($row['id'] != 1 && $row['id'] != $_SESSION['user_id']): ?>
                                        <a href="?hapus=<?= $row['id'] ?>" class="btn-danger" onclick="return confirm('Yakin hapus akun ini?')">Hapus</a>
                                    <?php else: ?>
                                        <span style="color: #999; font-size: 12px;">Terkunci</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
