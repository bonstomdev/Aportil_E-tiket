<?php 
require_once 'config.php'; 
checkAuth(); 

$hari_ini = date('Y-m-d');

// 1. Hitung Pendapatan Hari Ini (Hanya yang PAID)
$q_pendapatan = $mysqli->query("SELECT SUM(total_bayar) as total FROM booking b JOIN voyage v ON b.voyage_id = v.id WHERE b.status = 'Paid' AND v.tanggal = '$hari_ini'")->fetch_assoc();
$pendapatan = $q_pendapatan['total'] ?? 0;

// 2. Hitung Tiket Terjual Hari Ini
$q_tiket = $mysqli->query("SELECT COUNT(t.id) as total FROM tiket t JOIN booking b ON t.booking_id = b.id JOIN voyage v ON b.voyage_id = v.id WHERE b.status = 'Paid' AND v.tanggal = '$hari_ini'")->fetch_assoc();
$tiket_terjual = $q_tiket['total'] ?? 0;

// 3. Hitung Total Voyage Hari Ini
$q_voyage = $mysqli->query("SELECT COUNT(id) as total FROM voyage WHERE tanggal = '$hari_ini'")->fetch_assoc();
$voyage_hari_ini = $q_voyage['total'] ?? 0;

// 4. Hitung Total Pending (Belum Bayar)
$q_pending = $mysqli->query("SELECT COUNT(id) as total FROM booking WHERE status = 'Pending'")->fetch_assoc();
$total_pending = $q_pending['total'] ?? 0;

// 5. DATA UNTUK GRAFIK PENDAPATAN 7 HARI TERAKHIR
$chart_labels = [];
$chart_data = [];
for ($i = 6; $i >= 0; $i--) {
    $tgl = date('Y-m-d', strtotime("-$i days"));
    $chart_labels[] = date('d M', strtotime($tgl));
    $q_chart = $mysqli->query("SELECT SUM(total_bayar) as total FROM booking WHERE status = 'Paid' AND DATE(created_at) = '$tgl'")->fetch_assoc();
    $chart_data[] = (float)($q_chart['total'] ?? 0);
}

// 6. DATA UNTUK GRAFIK ANALITIK RUTE (Top 5)
$rute_labels = [];
$rute_data = [];
$q_rute = $mysqli->query("SELECT CONCAT(p1.nama, ' ➔ ', p2.nama) as rute, COUNT(t.id) as total 
                          FROM tiket t 
                          JOIN booking b ON t.booking_id = b.id 
                          JOIN voyage v ON b.voyage_id = v.id 
                          JOIN pelabuhan p1 ON v.pelabuhan_asal_id = p1.id 
                          JOIN pelabuhan p2 ON v.pelabuhan_tujuan_id = p2.id 
                          WHERE b.status = 'Paid' 
                          GROUP BY v.pelabuhan_asal_id, v.pelabuhan_tujuan_id 
                          ORDER BY total DESC LIMIT 5");
while($r = $q_rute->fetch_assoc()) { 
    $rute_labels[] = $r['rute']; 
    $rute_data[] = $r['total']; 
}

// 7. DATA UNTUK GRAFIK ANALITIK KAPAL (Top 5)
$kapal_labels = [];
$kapal_data = [];
$q_kapal = $mysqli->query("SELECT k.nama_kapal, COUNT(t.id) as total 
                           FROM tiket t 
                           JOIN booking b ON t.booking_id = b.id 
                           JOIN voyage v ON b.voyage_id = v.id 
                           JOIN kapal k ON v.kapal_id = k.id 
                           WHERE b.status = 'Paid' 
                           GROUP BY k.id 
                           ORDER BY total DESC LIMIT 5");
while($k = $q_kapal->fetch_assoc()) { 
    $kapal_labels[] = $k['nama_kapal']; 
    $kapal_data[] = $k['total']; 
}

$notif_cancel = '';
if (isset($_SESSION['auto_cancel_count'])) {
    $jml = $_SESSION['auto_cancel_count'];
    $notif_cancel = "<div class='alert-error' style='margin-bottom: 20px; border-left: 5px solid #d32f2f;'>🤖 <b>Sistem Auto-Cancel:</b> Sebanyak <b>$jml pesanan</b> yang belum dibayar selama 2 jam telah otomatis dibatalkan dan kursinya dikembalikan ke sistem.</div>";
    unset($_SESSION['auto_cancel_count']); 
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dasbor Admin - APORTIL Ferry</title>
    <link rel="stylesheet" href="style.css">
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#0B2E6F">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .chart-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px; margin-top: 30px; }
        .chart-card { background: var(--white); padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border: 1px solid var(--border); }
        .chart-card h3 { margin-bottom: 15px; color: var(--primary); border-bottom: 2px solid var(--border); padding-bottom: 10px; font-size: 15px; }
        body.dark-mode .chart-card h3 { color: #90caf9; }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= ucfirst($_SESSION['role'] ?? 'kasir') ?>)</span>
            <a href="pesan.php" class="btn-logout" style="background: #2e7d32; margin-right: 10px;">👁️ Halaman Penumpang</a>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php" class="active">📊 Dasbor</a>
            <?php if(($_SESSION['role'] ?? '') == 'admin'): ?>
                <a href="pelabuhan.php">⚓ Master Pelabuhan</a>
                <a href="kapal.php">🚢 Master Kapal</a>
                <a href="rute.php">🗺️ Master Rute</a>
                <a href="voyage.php">⏰ Jadwal Voyage</a>
            <?php endif; ?>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <?php if(($_SESSION['role'] ?? '') == 'admin'): ?>
                <a href="laporan.php">📑 Laporan</a>
                <a href="z_report.php">🧾 Z-Report Kasir</a>
                <a href="voucher.php">🎟️ Voucher Promo</a>
                <a href="profil.php">🏢 Profil Perusahaan</a>
                <a href="users.php">👥 Manajemen Pegawai</a>
                <a href="log.php">🕵️‍♂️ Log Aktivitas</a>
                <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
                <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
            <?php endif; ?>
        </div>

        <div class="main-content">
            <h2>Ringkasan Hari Ini (<?= date('d M Y') ?>)</h2>
            <p>Pantau aktivitas pelabuhan dan penjualan tiket secara real-time.</p>
            
            <?= $notif_cancel ?>

            <div class="stats-grid">
                <div class="stat-box bg-blue" style="background: var(--white); border-left: 5px solid #0B2E6F;">
                    <div class="stat-icon">💰</div>
                    <div class="stat-info">
                        <span class="stat-label" style="color: var(--text); opacity: 0.7;">Pendapatan (Paid)</span>
                        <h3 class="stat-value" style="color: var(--text);">$<?= number_format($pendapatan, 2) ?></h3>
                    </div>
                </div>
                <div class="stat-box bg-green" style="background: var(--white); border-left: 5px solid #2e7d32;">
                    <div class="stat-icon">🎫</div>
                    <div class="stat-info">
                        <span class="stat-label" style="color: var(--text); opacity: 0.7;">Tiket Terjual</span>
                        <h3 class="stat-value" style="color: var(--text);"><?= $tiket_terjual ?> Tiket</h3>
                    </div>
                </div>
                <div class="stat-box bg-orange" style="background: var(--white); border-left: 5px solid #ff9800;">
                    <div class="stat-icon">⏰</div>
                    <div class="stat-info">
                        <span class="stat-label" style="color: var(--text); opacity: 0.7;">Voyage Hari Ini</span>
                        <h3 class="stat-value" style="color: var(--text);"><?= $voyage_hari_ini ?> Jadwal</h3>
                    </div>
                </div>
                <div class="stat-box bg-red" style="background: var(--white); border-left: 5px solid #d32f2f;">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-info">
                        <span class="stat-label" style="color: var(--text); opacity: 0.7;">Menunggu Verifikasi</span>
                        <h3 class="stat-value" style="color: var(--text);"><?= $total_pending ?> Pesanan</h3>
                    </div>
                </div>
            </div>

            <?php if(($_SESSION['role'] ?? '') == 'admin'): ?>
            
            <!-- GRAFIK PENDAPATAN -->
            <div class="card" style="margin-top: 30px;">
                <h3>📈 Tren Pendapatan 7 Hari Terakhir</h3>
                <div style="position: relative; height: 300px; width: 100%; margin-top: 15px;">
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>

            <!-- GRAFIK ANALITIK BARU -->
            <div class="chart-grid">
                <div class="chart-card">
                    <h3>🏆 Top 5 Rute Terpopuler</h3>
                    <div style="position: relative; height: 250px; width: 100%;">
                        <canvas id="ruteChart"></canvas>
                    </div>
                </div>
                <div class="chart-card">
                    <h3>🚢 Top 5 Kapal Tersibuk</h3>
                    <div style="position: relative; height: 250px; width: 100%;">
                        <canvas id="kapalChart"></canvas>
                    </div>
                </div>
            </div>

            <div class="alert-success" style="margin-top: 20px;">
                ✅ Semua sistem berjalan normal. <br>
                Sistem <b>Auto-Cancel</b> aktif: Pesanan yang tidak dibayar lebih dari 2 jam akan dibatalkan otomatis.
            </div>

            <div style="margin-top: 20px; text-align: center;">
                <a href="backup.php" class="btn-primary" style="display: inline-block; width: auto; padding: 12px 25px; text-decoration: none; background: #d32f2f;">
                    ⬇️ Download Backup Database (.sql)
                </a>
                <p style="font-size: 12px; color: var(--text); opacity: 0.6; margin-top: 10px;">Simpan file ini di tempat aman (Google Drive/Flashdisk) sebagai cadangan.</p>
            </div>
            <?php else: ?>
            <div class="alert-success" style="margin-top: 20px;">
                ✅ Anda login sebagai <b>Kasir</b>. Silakan gunakan menu <b>Verifikasi Tiket</b> atau <b>Scan QR</b> untuk melayani penumpang.
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        <?php if(($_SESSION['role'] ?? '') == 'admin'): ?>
        // 1. GRAFIK PENDAPATAN
        const ctxRev = document.getElementById('revenueChart').getContext('2d');
        new Chart(ctxRev, {
            type: 'bar',
            data: {
                labels: <?= json_encode($chart_labels) ?>,
                datasets: [{
                    label: 'Pendapatan ($ USD)',
                    data: <?= json_encode($chart_data) ?>,
                    backgroundColor: 'rgba(11, 46, 111, 0.7)',
                    borderColor: 'rgba(11, 46, 111, 1)',
                    borderWidth: 1,
                    borderRadius: 5
                }]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
        });

        // 2. GRAFIK RUTE TERPOPULER
        const ctxRute = document.getElementById('ruteChart').getContext('2d');
        new Chart(ctxRute, {
            type: 'doughnut', // Menggunakan Donat agar lebih menarik
            data: {
                labels: <?= json_encode($rute_labels) ?>,
                datasets: [{
                    data: <?= json_encode($rute_data) ?>,
                    backgroundColor: ['#0B2E6F', '#2e7d32', '#ff9800', '#d32f2f', '#6a1b9a'],
                }]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
        });

        // 3. GRAFIK KAPAL TERSIBUK
        const ctxKapal = document.getElementById('kapalChart').getContext('2d');
        new Chart(ctxKapal, {
            type: 'bar', // Grafik batang horizontal
            data: {
                labels: <?= json_encode($kapal_labels) ?>,
                datasets: [{
                    label: 'Jumlah Penumpang',
                    data: <?= json_encode($kapal_data) ?>,
                    backgroundColor: 'rgba(46, 125, 50, 0.7)',
                    borderColor: 'rgba(46, 125, 50, 1)',
                    borderWidth: 1,
                    borderRadius: 5
                }]
            },
            options: { 
                indexAxis: 'y', // Membuat batang menjadi horizontal
                responsive: true, 
                maintainAspectRatio: false, 
                plugins: { legend: { display: false } } 
            }
        });
        <?php endif; ?>

        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('sw.js').then(function() {}).catch(function(err) {});
        }
    </script>
</body>
</html>
