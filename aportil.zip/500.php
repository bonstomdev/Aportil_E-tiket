<?php
require_once 'config.php';
http_response_code(500);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>500 - Kesalahan Server | APORTIL</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .error-container { display: flex; justify-content: center; align-items: center; min-height: 100vh; background: var(--bg); padding: 20px; text-align: center; }
        .error-box { background: var(--white); padding: 50px 30px; border-radius: 20px; box-shadow: 0 15px 35px rgba(0,0,0,0.1); max-width: 500px; width: 100%; border: 1px solid var(--border); }
        .error-code { font-size: 100px; font-weight: 900; color: #d32f2f; margin: 0; line-height: 1; text-shadow: 4px 4px 0px rgba(211, 47, 47, 0.2); }
        .error-icon { font-size: 60px; animation: shake 0.5s ease-in-out infinite; margin-bottom: 10px; }
        @keyframes shake { 0% { transform: translate(1px, 1px) rotate(0deg); } 10% { transform: translate(-1px, -2px) rotate(-1deg); } 20% { transform: translate(-3px, 0px) rotate(1deg); } 30% { transform: translate(3px, 2px) rotate(0deg); } 40% { transform: translate(1px, -1px) rotate(1deg); } 50% { transform: translate(-1px, 2px) rotate(-1deg); } 60% { transform: translate(-3px, 1px) rotate(0deg); } 70% { transform: translate(3px, 1px) rotate(-1deg); } 80% { transform: translate(-1px, -1px) rotate(1deg); } 90% { transform: translate(1px, 2px) rotate(0deg); } 100% { transform: translate(1px, -2px) rotate(-1deg); } }
        .error-title { font-size: 24px; color: var(--text); margin-bottom: 10px; font-weight: 700; }
        .error-desc { font-size: 15px; color: var(--text); opacity: 0.7; margin-bottom: 30px; line-height: 1.6; }
        .btn-home { display: inline-block; padding: 15px 30px; background: var(--primary); color: white; text-decoration: none; border-radius: 10px; font-weight: bold; font-size: 16px; transition: 0.3s; box-shadow: 0 4px 15px rgba(11,46,111,0.3); }
        .btn-home:hover { transform: translateY(-3px); filter: brightness(1.2); }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-box">
            <div class="error-icon">⚙️</div>
            <h1 class="error-code">500</h1>
            <h2 class="error-title">Kesalahan Server Internal</h2>
            <p class="error-desc">Maaf, kapal sedang mengalami kendala teknis di ruang mesin. Tim kami sedang memperbaikinya. Silakan coba beberapa saat lagi.</p>
            <a href="pesan.php" class="btn-home">⚓ Kembali ke Beranda</a>
        </div>
    </div>
</body>
</html>
