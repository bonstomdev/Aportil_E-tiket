<?php
require_once 'config.php';

$msg = '';
$kode = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode = strtoupper(trim($_POST['kode_booking'] ?? ''));
    
    if ($kode) {
        $stmt = $mysqli->prepare("SELECT id, status FROM booking WHERE kode_booking = ?");
        $stmt->bind_param('s', $kode);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($res) {
            if ($res['status'] == 'Paid') {
                // Jika tiket lunas, langsung arahkan ke halaman E-Ticket
                header("Location: tiket.php?kode=" . urlencode($kode));
                exit;
            } elseif ($res['status'] == 'Pending') {
                $msg = "<div class='alert-error'>⚠️ Status tiket Anda masih <b>PENDING</b> (Menunggu Pembayaran/Validasi). Silakan hubungi Admin atau selesaikan pembayaran Anda.</div>";
            } else {
                $msg = "<div class='alert-error'>❌ Tiket dengan kode ini telah <b>DIBATALKAN</b>. Silakan pesan tiket baru.</div>";
            }
        } else {
            $msg = "<div class='alert-error'>❌ Kode Booking tidak ditemukan. Silakan periksa kembali.</div>";
        }
    } else {
        $msg = "<div class='alert-error'>Harap masukkan Kode Booking.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cek Tiket - APORTIL Ferry</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background: #eef1f7;">

    <nav class="navbar" style="background: #0B2E6F; display: flex; justify-content: space-between; align-items: center; padding: 10px 15px;">
        <div class="logo" style="font-weight: bold; color: white;">⚓ <?= htmlspecialchars($SETTINGS['nama_perusahaan'] ?? 'APORTIL Ferry') ?></div>
        <div class="user-info">
            <a href="pesan.php" style="color: white; text-decoration: none; font-size: 14px;">Pesan Tiket Baru</a>
        </div>
    </nav>

    <div style="max-width: 500px; margin: 50px auto; padding: 20px;">
        <div class="card" style="text-align: center;">
            <h2 style="color: #0B2E6F; margin-bottom: 5px;">🔍 Cek E-Ticket</h2>
            <p style="color: #666; margin-bottom: 25px; font-size: 14px;">Masukkan Kode Booking Anda untuk melihat atau mencetak ulang tiket.</p>
            
            <?= $msg ?>

            <form method="POST">
                <div class="form-group">
                    <input type="text" name="kode_booking" placeholder="Contoh: APT-261110-ABCD" value="<?= htmlspecialchars($kode) ?>" required style="text-transform: uppercase; text-align: center; font-size: 18px; font-family: monospace; letter-spacing: 2px; padding: 15px;">
                </div>
                <button type="submit" class="btn-primary">Cari Tiket</button>
            </form>
            
            <div style="margin-top: 20px;">
                <a href="pesan.php" style="color: #0B2E6F; font-size: 13px; text-decoration: none; font-weight: bold;">← Kembali ke Halaman Utama</a>
            </div>
        </div>
    </div>

</body>
</html>
