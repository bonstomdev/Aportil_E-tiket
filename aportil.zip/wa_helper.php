<?php
date_default_timezone_set('Asia/Dili'); 

function getWhatsAppMessage($nama, $kode_booking, $total) {
    $domain = "http://" . $_SERVER['HTTP_HOST'];
    $link_tiket = $domain . "/tiket.php?kode=" . $kode_booking;
    
    $pesan = "Halo *" . $nama . "*,\n\n";
    $pesan .= "Pembayaran Anda untuk tiket APORTIL telah *BERHASIL DIVALIDASI*.\n\n";
    $pesan .= "🎫 Kode Booking: *" . $kode_booking . "*\n";
    $pesan .= "💵 Total: *$" . number_format($total, 2) . " USD*\n\n";
    $pesan .= "Silakan buka E-Ticket Anda (ada QR Code untuk boarding) di link berikut:\n";
    $pesan .= $link_tiket . "\n\n";
    $pesan .= "Terima kasih telah menggunakan layanan APORTIL. Selamat berlayar! ⚓🚢";
    
    return $pesan;
}

function sendWhatsAppAPI($no_hp, $pesan, $token_fonnte = '') {
    if (empty($token_fonnte)) return false;

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.fonnte.com/send',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array(
            'target' => $no_hp,
            'message' => $pesan,
        ),
        CURLOPT_HTTPHEADER => array(
            'Authorization: ' . $token_fonnte
        ),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
}
?>
