<?php
require_once 'config.php';
checkAuth(); // Bisa diakses oleh Admin dan Kasir

$keyword = trim($_GET['q'] ?? '');
$result = null;

if ($keyword !== '') {
    $like = '%' . $keyword . '%';
    $sql = "SELECT t.*, b.kode_booking, b.status AS status_booking, v.kode_voyage, v.tanggal, k.nama_kapal, p1.nama as asal, p2.nama as tujuan
            FROM tiket t 
            JOIN booking b ON t.booking_id = b.id 
            JOIN voyage v ON b.voyage_id = v.id 
            JOIN kapal k ON v.kapal_id = k.id
            JOIN pelabuhan p1 ON v.pelabuhan_asal_id = p1.id
            JOIN pelabuhan p2 ON v.pelabuhan_tujuan_id = p2.id
            WHERE t.nama_penumpang LIKE ? OR t.no_identitas LIKE ? OR b.kode_booking LIKE ?
            ORDER BY b.created_at DESC LIMIT 100";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('sss', $like, $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cari Penumpang - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= ucfirst($_SESSION['role'] ?? 'kasir') ?>)</span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <?php if(($_SESSION['role'] ?? '') == 'admin'): ?>
                <a href="pelabuhan.php">⚓ Master Pelabuhan</a>
                <a href="kapal.php">🚢 Master Kapal</a>
                <a href="rute.php">🗺️ Master Rute</a>
                <a href="voyage.php">⏰ Jadwal Voyage</a>
            <?php endif; ?>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="cari_penumpang.php" class="active">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <?php if(($_SESSION['role'] ?? '') == 'admin'): ?>
                <a href="laporan.php">📑 Laporan</a>
                <a href="z_report.php">🧾 Z-Report Kasir</a>
                <a href="voucher.php">🎟️ Voucher Promo</a>
                <a href="profil.php">🏢 Profil Perusahaan</a>
                <a href="users.php">👥 Manajemen Pegawai</a>
                <a href="log.php">🕵️‍♂️ Log Aktivitas</a>
                <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
                <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
            <?php endif; ?>
        </div>

        <div class="main-content">
            <h2>Pencarian Data Penumpang</h2>
            <p>Cari berdasarkan Nama Penumpang, No. Identitas (KTP/Passport), atau Kode Booking.</p>

            <div class="card">
                <form method="GET" style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <input type="text" name="q" value="<?= htmlspecialchars($keyword) ?>" placeholder="Ketik Nama, No. Identitas, atau Kode Booking..." style="flex: 1; min-width: 250px; padding: 12px; border: 1px solid var(--border); border-radius: 8px; font-size: 16px;">
                    <button type="submit" class="btn-primary" style="width: auto; padding: 12px 30px; margin: 0;">🔍 Cari</button>
                    <?php if($keyword): ?>
                        <a href="cari_penumpang.php" class="btn-primary" style="background: #666; text-decoration: none; width: auto; padding: 12px 20px; margin: 0; text-align: center;">Reset</a>
                    <?php endif; ?>
                </form>
            </div>

            <?php if ($keyword !== ''): ?>
                <div class="card" style="margin-top: 20px;">
                    <h3>Hasil Pencarian untuk: "<?= htmlspecialchars($keyword) ?>"</h3>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Nama Penumpang</th>
                                    <th>No. Identitas & Negara</th>
                                    <th>Kode Booking</th>
                                    <th>Jadwal & Voyage</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($result && $result->num_rows > 0): ?>
                                    <?php while($row = $result->fetch_assoc()): ?>
                                    <tr>
                                        <td>
                                            <b><?= htmlspecialchars($row['nama_penumpang']) ?></b><br>
                                            <small>Kelas: <?= $row['kelas'] ?></small>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars($row['no_identitas']) ?><br>
                                            <small>🌍 <?= htmlspecialchars($row['negara'] ?? 'Timor-Leste') ?></small>
                                        </td>
                                        <td><span style="font-family: monospace; font-weight: bold; background: #eee; padding: 2px 6px; border-radius: 4px;"><?= htmlspecialchars($row['kode_booking']) ?></b></span></td>
                                        <td>
                                            <?= date('d M Y', strtotime($row['tanggal'])) ?><br>
                                            <small><?= htmlspecialchars($row['nama_kapal']) ?> (<?= $row['kode_voyage'] ?>)</small><br>
                                            <small><?= htmlspecialchars($row['asal']) ?> ➔ <?= htmlspecialchars($row['tujuan']) ?></small>
                                        </td>
                                        <td>
                                            <?php if($row['status_booking'] == 'Paid'): ?>
                                                <span style="background: #e8f5e9; color: #2e7d32; padding: 2px 6px; border-radius: 4px; font-size: 12px; font-weight: bold;">✅ PAID</span>
                                            <?php elseif($row['status_booking'] == 'Pending'): ?>
                                                <span style="background: #fff3e0; color: #e65100; padding: 2px 6px; border-radius: 4px; font-size: 12px; font-weight: bold;">⏳ PENDING</span>
                                            <?php else: ?>
                                                <span style="background: #ffebee; color: #d32f2f; padding: 2px 6px; border-radius: 4px; font-size: 12px; font-weight: bold;">❌ CANCELLED</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(!empty($row['foto_identitas'])): ?>
                                                <a href="uploads/<?= htmlspecialchars($row['foto_identitas']) ?>" target="_blank" class="btn-primary" style="background: #6a1b9a; padding: 6px 12px; font-size: 12px; display: inline-block; width: auto; text-decoration: none;">👁️ Foto ID</a>
                                            <?php else: ?>
                                                <small style="color: #999;">Tidak ada foto</small>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="6" style="text-align:center;">Data penumpang tidak ditemukan.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
