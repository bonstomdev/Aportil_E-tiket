<?php
require_once 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset'])) {
    $username = trim($_POST['username']);
    $kode_rahasia = trim($_POST['kode_rahasia']);
    $pass_baru = $_POST['pass_baru'];
    $konfirmasi = $_POST['konfirmasi'];

    if ($username && $kode_rahasia && $pass_baru && $konfirmasi) {
        $stmt = $mysqli->prepare("SELECT id, kode_rahasia FROM users WHERE username = ?");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($user) {
            if (empty($user['kode_rahasia'])) {
                $error = "Akun ini belum mengatur Kode Rahasia. Hubungi Super Admin / pemilik sistem.";
            } elseif (password_verify($kode_rahasia, $user['kode_rahasia'])) {
                if ($pass_baru !== $konfirmasi) {
                    $error = "Konfirmasi password baru tidak cocok!";
                } elseif (strlen($pass_baru) < 6) {
                    $error = "Password baru minimal 6 karakter!";
                } else {
                    $new_hash = password_hash($pass_baru, PASSWORD_DEFAULT);
                    $upd = $mysqli->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $upd->bind_param('si', $new_hash, $user['id']);
                    if ($upd->execute()) {
                        $success = "✅ Password berhasil direset! Silakan login dengan password baru Anda.";
                    } else {
                        $error = "Gagal mereset password.";
                    }
                    $upd->close();
                }
            } else {
                $error = "Kode Rahasia salah!";
            }
        } else {
            $error = "Username tidak ditemukan.";
        }
    } else {
        $error = "Harap isi semua kolom.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lupa Password - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="login-page">
    <div class="login-box glass-effect">
        <h1>🗝️ Lupa Password</h1>
        <p>Masukkan Username dan Kode Rahasia Anda untuk mereset password.</p>
        
        <?php if ($error): ?>
            <div class="alert-error" style="text-align: left; margin-bottom: 15px;"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert-success" style="text-align: left; margin-bottom: 15px; background: rgba(46, 125, 50, 0.9); color: white; border: none;"><?= htmlspecialchars($success) ?></div>
            <a href="login.php" class="btn-primary" style="display: block; text-decoration: none; margin-top: 15px; background: #2e7d32;">Ke Halaman Login</a>
        <?php else: ?>
            <form method="POST">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" placeholder="Masukkan username" required>
                </div>
                <div class="form-group">
                    <label>Kode Rahasia</label>
                    <input type="text" name="kode_rahasia" placeholder="Masukkan kode rahasia" required>
                </div>
                <div class="form-group">
                    <label>Password Baru (Min. 6 Karakter)</label>
                    <input type="password" name="pass_baru" placeholder="Masukkan password baru" required minlength="6">
                </div>
                <div class="form-group">
                    <label>Konfirmasi Password Baru</label>
                    <input type="password" name="konfirmasi" placeholder="Ketik ulang password baru" required>
                </div>
                <button type="submit" name="reset" class="btn-primary" style="background: #ff9800;">Reset Password</button>
            </form>
            <div style="margin-top: 20px;">
                <a href="login.php" style="color: #fff; font-size: 13px; text-decoration: none; opacity: 0.8;">← Kembali ke Login</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
