<?php
require_once 'config.php';
checkAuth(); 
checkAdmin();

$msg = '';
$edit_mode = false;
$data_edit = ['id' => '', 'nama_kapal' => '', 'kapasitas_ekonomi' => '', 'kapasitas_bisnis' => ''];

if (isset($_GET['edit'])) {
    $edit_mode = true;
    $id = (int)$_GET['edit'];
    $stmt = $mysqli->prepare("SELECT * FROM kapal WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $data_edit = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['tambah']) || isset($_POST['update']))) {
    verifyCsrfToken($_POST['csrf_token']);
    $nama = trim($_POST['nama_kapal']);
    $kap_eko = (int)$_POST['kapasitas_ekonomi'];
    $kap_bis = (int)$_POST['kapasitas_bisnis'];

    if ($nama !== '') {
        if (isset($_POST['update'])) {
            $id = (int)$_POST['id'];
            $stmt = $mysqli->prepare("UPDATE kapal SET nama_kapal=?, kapasitas_ekonomi=?, kapasitas_bisnis=? WHERE id=?");
            $stmt->bind_param('siii', $nama, $kap_eko, $kap_bis, $id);
            $stmt->execute();
            $msg = "<div class='alert-success'>✅ Data kapal <b>$nama</b> berhasil diperbarui!</div>";
        } else {
            $stmt = $mysqli->prepare("INSERT INTO kapal (nama_kapal, kapasitas_ekonomi, kapasitas_bisnis) VALUES (?, ?, ?)");
            $stmt->bind_param('sii', $nama, $kap_eko, $kap_bis);
            $stmt->execute();
            $msg = "<div class='alert-success'>✅ Kapal <b>$nama</b> berhasil ditambahkan!</div>";
        }
        $stmt->close();
        $edit_mode = false;
    }
}

if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $stmt = $mysqli->prepare("DELETE FROM kapal WHERE id = ?");
    $stmt->bind_param('i', $id);
    if ($stmt->execute()) {
        $msg = "<div class='alert-error'>🗑️ Kapal berhasil dihapus!</div>";
    }
    $stmt->close();
}

$result = $mysqli->query("SELECT * FROM kapal ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Kapal - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= ucfirst($_SESSION['role']) ?>)</span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="pelabuhan.php">⚓ Master Pelabuhan</a>
            <a href="kapal.php" class="active">🚢 Master Kapal</a>
            <a href="rute.php">🗺️ Master Rute</a>
            <a href="voyage.php">⏰ Jadwal Voyage</a>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <a href="laporan.php">📑 Laporan</a>
            <a href="z_report.php">🧾 Z-Report Kasir</a>
            <a href="voucher.php">🎟️ Voucher Promo</a>
            <a href="profil.php">🏢 Profil Perusahaan</a>
            <a href="users.php">👥 Manajemen Pegawai</a>
            <a href="log.php">🕵️‍♂️ Log Aktivitas</a>
            <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
            <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
        </div>

        <div class="main-content">
            <h2>Manajemen Kapal</h2>
            <p>Kelola data kapal feri beserta kapasitas kursinya.</p>
            
            <?= $msg ?>

            <div class="card">
                <h3><?= $edit_mode ? 'Edit Data Kapal' : 'Tambah Kapal Baru' ?></h3>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <?php if($edit_mode): ?>
                        <input type="hidden" name="id" value="<?= $data_edit['id'] ?>">
                    <?php endif; ?>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Nama Kapal</label>
                            <input type="text" name="nama_kapal" placeholder="Misal: Berlin Nakroma" value="<?= htmlspecialchars($data_edit['nama_kapal'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Kapasitas Ekonomi</label>
                            <input type="number" name="kapasitas_ekonomi" placeholder="Misal: 300" value="<?= htmlspecialchars($data_edit['kapasitas_ekonomi'] ?? '') ?>" required min="0">
                        </div>
                        <div class="form-group">
                            <label>Kapasitas Bisnis (Isi 0 jika tidak ada)</label>
                            <input type="number" name="kapasitas_bisnis" placeholder="Misal: 12" value="<?= htmlspecialchars($data_edit['kapasitas_bisnis'] ?? '') ?>" required min="0">
                        </div>
                    </div>
                    
                    <?php if($edit_mode): ?>
                        <button type="submit" name="update" class="btn-primary" style="width: auto; padding: 10px 20px; background: #e65100;">💾 Simpan Perubahan</button>
                        <a href="kapal.php" class="btn-primary" style="width: auto; padding: 10px 20px; background: #666; text-decoration: none; display: inline-block;">Batal</a>
                    <?php else: ?>
                        <button type="submit" name="tambah" class="btn-primary" style="width: auto; padding: 10px 20px;">+ Simpan Kapal</button>
                    <?php endif; ?>
                </form>
            </div>

            <div class="card" style="margin-top: 20px;">
                <h3>Daftar Kapal</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Kapal</th>
                                <th>Ekonomi</th>
                                <th>Bisnis</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no=1; while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><b><?= htmlspecialchars($row['nama_kapal']) ?></b></td>
                                <td><?= $row['kapasitas_ekonomi'] ?> Kursi</td>
                                <td><?= $row['kapasitas_bisnis'] > 0 ? $row['kapasitas_bisnis'].' Kursi' : '-' ?></td>
                                <td style="white-space: nowrap;">
                                    <a href="?edit=<?= $row['id'] ?>" class="btn-primary" style="background: #f57c00; padding: 6px 12px; font-size: 12px; display: inline-block; width: auto; text-decoration: none;">✏️ Edit</a>
                                    <a href="?hapus=<?= $row['id'] ?>" class="btn-danger" onclick="return confirm('Yakin ingin menghapus kapal ini?')">🗑️ Hapus</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</body>
</html>
