<?php
require_once 'config.php';
checkAuth(); checkAdmin(); checkAdmin(); 

$msg = '';

// Proses Tambah Rute
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    verifyCsrfToken($_POST['csrf_token']);
    
    $asal = (int)$_POST['asal'];
    $tujuan = (int)$_POST['tujuan'];
    $tarif_eko = (float)$_POST['tarif_eko'];
    $tarif_bis = (float)$_POST['tarif_bis'];
    $tarif_motor = (float)$_POST['tarif_motor'];
    $tarif_mobil = (float)$_POST['tarif_mobil'];
    $tarif_kargo = (float)$_POST['tarif_kargo'];
    $pulang_pergi = isset($_POST['pulang_pergi']);

    if ($asal === $tujuan) {
        $msg = "<div class='alert-error'>❌ Pelabuhan asal dan tujuan tidak boleh sama!</div>";
    } else {
        // Simpan Rute Utama
        $stmt = $mysqli->prepare("INSERT INTO tarif (pelabuhan_asal_id, pelabuhan_tujuan_id, harga_ekonomi, harga_bisnis, harga_motor, harga_mobil, harga_kargo) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('iiddddd', $asal, $tujuan, $tarif_eko, $tarif_bis, $tarif_motor, $tarif_mobil, $tarif_kargo);
        $stmt->execute();
        $stmt->close();

        // Jika centang pulang-pergi, simpan rute sebaliknya
        if ($pulang_pergi) {
            $stmt2 = $mysqli->prepare("INSERT INTO tarif (pelabuhan_asal_id, pelabuhan_tujuan_id, harga_ekonomi, harga_bisnis, harga_motor, harga_mobil, harga_kargo) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt2->bind_param('iiddddd', $tujuan, $asal, $tarif_eko, $tarif_bis, $tarif_motor, $tarif_mobil, $tarif_kargo);
            $stmt2->execute();
            $stmt2->close();
        }
        $msg = "<div class='alert-success'>✅ Rute berhasil ditambahkan!</div>";
    }
}

// Proses Hapus Rute
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $stmt = $mysqli->prepare("DELETE FROM tarif WHERE id = ?");
    $stmt->bind_param('i', $id);
    if ($stmt->execute()) {
        $msg = "<div class='alert-error'>🗑️ Rute berhasil dihapus!</div>";
    }
    $stmt->close();
}

// Ambil data pelabuhan untuk dropdown
$pelabuhan = $mysqli->query("SELECT * FROM pelabuhan");

// Ambil data rute (gabungkan tabel tarif dengan tabel pelabuhan)
$sql_rute = "SELECT t.*, 
             p1.nama as asal_nama, 
             p2.nama as tujuan_nama 
             FROM tarif t 
             JOIN pelabuhan p1 ON t.pelabuhan_asal_id = p1.id 
             JOIN pelabuhan p2 ON t.pelabuhan_tujuan_id = p2.id 
             ORDER BY t.id DESC";
$result = $mysqli->query($sql_rute);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Rute - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="kapal.php">⚓ Master Pelabuhan
            <a href="kapal.php">🚢 Master Kapal</a></a>
            <a href="rute.php" class="active">🗺️ Master Rute</a>
            <a href="#">⏰ Jadwal Voyage</a>
            <a href="#">📥 Verifikasi Tiket</a>
            <a href="#">📷 Scan QR</a>
            <a href="#">📑 Laporan
            <a href="z_report.php">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a>
            <a href="profil.php">🏢 Profil Perusahaan</a></a>
            <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
        </div>

        <div class="main-content">
            <h2>Manajemen Rute & Tarif</h2>
            <p>Atur jalur pelayaran beserta harga tiket, kendaraan, dan kargo.</p>
            
            <?= $msg ?>

            <div class="card">
                <h3>Tambah Rute Baru</h3>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Pelabuhan Asal</label>
                            <select name="asal" required style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ccc;">
                                <option value="">-- Pilih Asal --</option>
                                <?php $pelabuhan->data_seek(0); while($p = $pelabuhan->fetch_assoc()): ?>
                                    <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nama']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Pelabuhan Tujuan</label>
                            <select name="tujuan" required style="width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ccc;">
                                <option value="">-- Pilih Tujuan --</option>
                                <?php $pelabuhan->data_seek(0); while($p = $pelabuhan->fetch_assoc()): ?>
                                    <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nama']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row" style="margin-top: 15px;">
                        <div class="form-group">
                            <label>Harga Ekonomi ($)</label>
                            <input type="number" step="0.01" name="tarif_eko" value="4.00" required>
                        </div>
                        <div class="form-group">
                            <label>Harga Bisnis ($) (Isi 0 jika tidak ada)</label>
                            <input type="number" step="0.01" name="tarif_bis" value="10.00" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Harga Motor ($)</label>
                            <input type="number" step="0.01" name="tarif_motor" value="15.00" required>
                        </div>
                        <div class="form-group">
                            <label>Harga Mobil ($)</label>
                            <input type="number" step="0.01" name="tarif_mobil" value="35.00" required>
                        </div>
                        <div class="form-group">
                            <label>Harga Kargo / Koli ($)</label>
                            <input type="number" step="0.01" name="tarif_kargo" value="5.00" required>
                        </div>
                    </div>

                    <div class="form-group" style="display: flex; align-items: center; gap: 10px; margin: 15px 0;">
                        <input type="checkbox" name="pulang_pergi" id="pp" value="1" style="width: 20px; height: 20px;">
                        <label for="pp" style="margin: 0; cursor: pointer;">Buatkan otomatis rute sebaliknya (Pulang-Pergi)</label>
                    </div>

                    <button type="submit" name="tambah" class="btn-primary" style="width: auto; padding: 10px 20px;">+ Simpan Rute</button>
                </form>
            </div>

            <div class="card" style="margin-top: 20px;">
                <h3>Daftar Rute Aktif</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Rute</th>
                                <th>Ekonomi</th>
                                <th>Bisnis</th>
                                <th>Motor</th>
                                <th>Mobil</th>
                                <th>Kargo</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><b><?= htmlspecialchars($row['asal_nama']) ?> ➔ <?= htmlspecialchars($row['tujuan_nama']) ?></b></td>
                                <td>$<?= number_format($row['harga_ekonomi'], 2) ?></td>
                                <td><?= $row['harga_bisnis'] > 0 ? '$'.number_format($row['harga_bisnis'], 2) : '-' ?></td>
                                <td>$<?= number_format($row['harga_motor'], 2) ?></td>
                                <td>$<?= number_format($row['harga_mobil'], 2) ?></td>
                                <td>$<?= number_format($row['harga_kargo'], 2) ?></td>
                                <td>
                                    <a href="?hapus=<?= $row['id'] ?>" class="btn-danger" onclick="return confirm('Yakin ingin menghapus rute ini?')">Hapus</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</body>
</html>
