<?php
require_once 'config.php';
checkAuth(); checkAdmin(); checkAdmin();

$tanggal = $_GET['tanggal'] ?? date('Y-m-d');

// Query untuk mengambil ringkasan total
$sql_total = "SELECT 
    COUNT(DISTINCT b.id) as total_transaksi,
    SUM(b.total_bayar) as total_pendapatan,
    COUNT(t.id) as total_penumpang,
    SUM(CASE WHEN t.jenis_kendaraan != 'Tidak Ada' THEN 1 ELSE 0 END) as total_kendaraan,
    SUM(t.jumlah_kargo) as total_kargo
    FROM booking b
    JOIN tiket t ON b.id = t.booking_id
    WHERE b.status = 'Paid' AND DATE(b.created_at) = ?";
$stmt = $mysqli->prepare($sql_total);
$stmt->bind_param('s', $tanggal);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Query untuk rincian per Voyage
$sql_voyage = "SELECT v.kode_voyage, k.nama_kapal, p1.nama as asal, p2.nama as tujuan,
    COUNT(DISTINCT b.id) as trx_voyage,
    SUM(b.total_bayar) as pendapatan_voyage,
    COUNT(t.id) as pax_voyage
    FROM booking b
    JOIN tiket t ON b.id = t.booking_id
    JOIN voyage v ON b.voyage_id = v.id
    JOIN kapal k ON v.kapal_id = k.id
    JOIN pelabuhan p1 ON v.pelabuhan_asal_id = p1.id
    JOIN pelabuhan p2 ON v.pelabuhan_tujuan_id = p2.id
    WHERE b.status = 'Paid' AND DATE(b.created_at) = ?
    GROUP BY v.id
    ORDER BY pendapatan_voyage DESC";
$stmt_v = $mysqli->prepare($sql_voyage);
$stmt_v->bind_param('s', $tanggal);
$stmt_v->execute();
$result_voyage = $stmt_v->get_result();
$stmt_v->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Z-Report Kasir - APORTIL</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Style khusus untuk struk Z-Report */
        .receipt-box {
            background: #fff;
            max-width: 500px;
            margin: 0 auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            font-family: 'Courier New', Courier, monospace;
            color: #333;
        }
        .receipt-header { text-align: center; border-bottom: 2px dashed #ccc; padding-bottom: 15px; margin-bottom: 15px; }
        .receipt-header h2 { margin: 0; color: #0B2E6F; font-family: 'Poppins', sans-serif; }
        .receipt-header p { margin: 5px 0 0; font-size: 14px; }
        
        .summary-row { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 15px; }
        .summary-row.total { font-weight: bold; font-size: 18px; border-top: 1px solid #333; padding-top: 10px; margin-top: 15px; color: #0B2E6F; }
        
        .divider { border-top: 2px dashed #ccc; margin: 20px 0; }
        
        .voyage-detail { margin-bottom: 15px; }
        .voyage-detail h4 { margin: 0 0 5px 0; font-size: 14px; border-bottom: 1px solid #eee; }
        .voyage-detail p { margin: 3px 0; font-size: 13px; display: flex; justify-content: space-between; }
        
        .receipt-footer { text-align: center; font-size: 12px; margin-top: 30px; color: #666; }

        @media print {
            body { background: #fff; }
            .navbar, .sidebar, .card form, .main-content > h2, .main-content > p, .btn-print { display: none !important; }
            .dashboard-container { display: block; }
            .main-content { padding: 0; }
            .receipt-box { box-shadow: none; border: none; padding: 0; }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="kapal.php">⚓ Master Pelabuhan
            <a href="kapal.php">🚢 Master Kapal</a></a>
            <a href="rute.php">🗺️ Master Rute</a>
            <a href="voyage.php">⏰ Jadwal Voyage</a>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <a href="laporan.php">📑 Laporan
            <a href="z_report.php">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a>
            <a href="profil.php">🏢 Profil Perusahaan</a></a></a>
            <a href="z_report.php" class="active">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a>
            <a href="profil.php">🏢 Profil Perusahaan</a></a>
            <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
            <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
        </div>

        <div class="main-content">
            <h2>Z-Report (Tutup Buku Kasir)</h2>
            <p>Ringkasan uang fisik yang harus ada di loket pada tanggal tertentu.</p>

            <div class="card" style="max-width: 500px; margin: 0 auto 20px auto;">
                <form method="GET" class="form-row" style="align-items: flex-end; margin: 0;">
                    <div class="form-group" style="flex: 1;">
                        <label>Pilih Tanggal Tutup Buku</label>
                        <input type="date" name="tanggal" value="<?= $tanggal ?>" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn-primary" style="padding: 12px;">Tampilkan</button>
                    </div>
                </form>
            </div>

            <!-- AREA STRUK Z-REPORT -->
            <div class="receipt-box" id="area-cetak">
                <div class="receipt-header">
                    <h2>⚓ APORTIL, I.P.</h2>
                    <p>Z-REPORT (TUTUP BUKU KASIR)</p>
                    <p>Tanggal: <b><?= date('d M Y', strtotime($tanggal)) ?></b></p>
                </div>

                <div class="summary-row">
                    <span>Total Transaksi</span>
                    <span><?= $total['total_transaksi'] ?? 0 ?> Transaksi</span>
                </div>
                <div class="summary-row">
                    <span>Total Penumpang</span>
                    <span><?= $total['total_penumpang'] ?? 0 ?> Orang</span>
                </div>
                <div class="summary-row">
                    <span>Total Kendaraan</span>
                    <span><?= $total['total_kendaraan'] ?? 0 ?> Unit</span>
                </div>
                <div class="summary-row">
                    <span>Total Kargo</span>
                    <span><?= $total['total_kargo'] ?? 0 ?> Koli</span>
                </div>

                <div class="summary-row total">
                    <span>TOTAL PENDAPATAN</span>
                    <span>$<?= number_format($total['total_pendapatan'] ?? 0, 2) ?> USD</span>
                </div>

                <div class="divider"></div>
                <h3 style="text-align: center; margin-bottom: 15px; font-size: 14px;">Rincian Per Voyage</h3>

                <?php if($result_voyage->num_rows > 0): ?>
                    <?php while($v = $result_voyage->fetch_assoc()): ?>
                        <div class="voyage-detail">
                            <h4><?= htmlspecialchars($v['kode_voyage']) ?> - <?= htmlspecialchars($v['nama_kapal']) ?></h4>
                            <p><span>Rute</span> <span><?= htmlspecialchars($v['asal']) ?> ➔ <?= htmlspecialchars($v['tujuan']) ?></span></p>
                            <p><span>Transaksi / Pax</span> <span><?= $v['trx_voyage'] ?> Trx / <?= $v['pax_voyage'] ?> Orang</span></p>
                            <p style="font-weight: bold;"><span>Pendapatan</span> <span>$<?= number_format($v['pendapatan_voyage'], 2) ?></span></p>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p style="text-align: center; font-size: 13px;">Tidak ada transaksi pada tanggal ini.</p>
                <?php endif; ?>

                <div class="receipt-footer">
                    Dicetak pada: <?= date('d/m/Y H:i:s') ?><br>
                    Oleh Admin: <?= htmlspecialchars($_SESSION['username']) ?><br><br>
                    <i>Tanda tangan Kasir: _________________</i>
                </div>
            </div>

            <div style="text-align: center; margin-top: 20px;">
                <button onclick="window.print()" class="btn-primary btn-print" style="width: auto; padding: 12px 30px; background: #0d47a1;">
                    🖨️ Cetak Z-Report
                </button>
            </div>
        </div>
    </div>
</body>
</html>
