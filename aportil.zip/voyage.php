<?php
require_once 'config.php';
checkAuth(); checkAdmin(); checkAdmin(); 

$msg = '';

// PROSES 1: TAMBAH JADWAL SATUAN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    verifyCsrfToken($_POST['csrf_token']);
    $kode = trim($_POST['kode_voyage']);
    $kapal_id = (int)$_POST['kapal_id'];
    $asal_id = (int)$_POST['asal_id'];
    $tujuan_id = (int)$_POST['tujuan_id'];
    $tanggal = $_POST['tanggal'];
    $jam = $_POST['jam'];

    if ($kode !== '' && $kapal_id > 0 && $asal_id > 0 && $tujuan_id > 0) {
        $stmt = $mysqli->prepare("INSERT INTO voyage (kode_voyage, kapal_id, pelabuhan_asal_id, pelabuhan_tujuan_id, tanggal, jam_berangkat) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('siiiss', $kode, $kapal_id, $asal_id, $tujuan_id, $tanggal, $jam);
        if ($stmt->execute()) {
            $msg = "<div class='alert-success'>✅ Jadwal Voyage <b>$kode</b> berhasil ditambahkan!</div>";
        }
        $stmt->close();
    }
}

// PROSES 2: TAMBAH JADWAL MINGGUAN (OTOMATIS)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_mingguan'])) {
    verifyCsrfToken($_POST['csrf_token']);
    $prefix = trim($_POST['prefix_voyage']);
    $kapal_id = (int)$_POST['kapal_id_mingguan'];
    $asal_id = (int)$_POST['asal_id_mingguan'];
    $tujuan_id = (int)$_POST['tujuan_id_mingguan'];
    $jam = $_POST['jam_mingguan'];
    $tgl_mulai = $_POST['tgl_mulai'];
    $hari_pilihan = $_POST['hari'] ?? [];

    if ($prefix !== '' && $kapal_id > 0 && $asal_id > 0 && $tujuan_id > 0 && !empty($hari_pilihan)) {
        $startDate = new DateTime($tgl_mulai);
        $endDate = clone $startDate;
        $endDate->modify('+6 days'); 

        $interval = new DateInterval('P1D');
        $daterange = new DatePeriod($startDate, $interval, $endDate->modify('+1 day'));
        $count = 0;

        $mysqli->begin_transaction();
        try {
            foreach ($daterange as $date) {
                $dayOfWeek = (int)$date->format('N'); // 1=Senin, 7=Minggu
                if (in_array($dayOfWeek, $hari_pilihan)) {
                    $tgl_format = $date->format('Y-m-d');
                    $kode_voyage = $prefix . '-' . $date->format('ymd');
                    
                    $stmt = $mysqli->prepare("INSERT INTO voyage (kode_voyage, kapal_id, pelabuhan_asal_id, pelabuhan_tujuan_id, tanggal, jam_berangkat) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param('siiiss', $kode_voyage, $kapal_id, $asal_id, $tujuan_id, $tgl_format, $jam);
                    $stmt->execute();
                    $stmt->close();
                    $count++;
                }
            }
            $mysqli->commit();
            $msg = "<div class='alert-success'>✅ Berhasil membuat <b>$count jadwal</b> secara otomatis untuk 1 minggu ke depan!</div>";
        } catch (Exception $e) {
            $mysqli->rollback();
            $msg = "<div class='alert-error'>❌ Gagal membuat jadwal: " . $e->getMessage() . "</div>";
        }
    } else {
        $msg = "<div class='alert-error'>❌ Harap lengkapi data dan pilih minimal 1 hari!</div>";
    }
}

// PROSES HAPUS
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $stmt = $mysqli->prepare("DELETE FROM voyage WHERE id = ?");
    $stmt->bind_param('i', $id);
    if ($stmt->execute()) {
        $msg = "<div class='alert-error'>🗑️ Jadwal Voyage berhasil dihapus!</div>";
    }
    $stmt->close();
}

$kapal = $mysqli->query("SELECT * FROM kapal");
$pelabuhan = $mysqli->query("SELECT * FROM pelabuhan");

$sql = "SELECT v.*, k.nama_kapal, k.kapasitas_ekonomi, k.kapasitas_bisnis, p1.nama as asal_nama, p2.nama as tujuan_nama,
        (SELECT COUNT(t.id) FROM tiket t JOIN booking b ON t.booking_id = b.id WHERE b.voyage_id = v.id AND b.status != 'Cancelled' AND t.kelas = 'Ekonomi') as terjual_eko,
        (SELECT COUNT(t.id) FROM tiket t JOIN booking b ON t.booking_id = b.id WHERE b.voyage_id = v.id AND b.status != 'Cancelled' AND t.kelas = 'Bisnis') as terjual_bis
        FROM voyage v 
        JOIN kapal k ON v.kapal_id = k.id 
        JOIN pelabuhan p1 ON v.pelabuhan_asal_id = p1.id 
        JOIN pelabuhan p2 ON v.pelabuhan_tujuan_id = p2.id 
        ORDER BY v.tanggal DESC, v.jam_berangkat ASC";
$result = $mysqli->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Voyage - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="kapal.php">⚓ Master Pelabuhan
            <a href="kapal.php">🚢 Master Kapal</a></a>
            <a href="rute.php">🗺️ Master Rute</a>
            <a href="voyage.php" class="active">⏰ Jadwal Voyage</a>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <a href="laporan.php">📑 Laporan
            <a href="z_report.php">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a>
            <a href="profil.php">🏢 Profil Perusahaan</a></a></a>
            <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
            <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
        </div>

        <div class="main-content">
            <h2>Jadwal Voyage</h2>
            <p>Atur jadwal keberangkatan kapal secara satuan atau otomatis untuk 1 minggu.</p>
            
            <?= $msg ?>

            <div class="form-row">
                <!-- FORM TAMBAH SATUAN -->
                <div class="card" style="flex: 1; min-width: 300px;">
                    <h3>📅 Buat Jadwal Satuan</h3>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        
                        <div class="form-group">
                            <label>Kode Voyage</label>
                            <input type="text" name="kode_voyage" placeholder="Misal: NAK-001" required>
                        </div>
                        <div class="form-group">
                            <label>Pilih Kapal</label>
                            <select name="kapal_id" required>
                                <option value="">-- Pilih Kapal --</option>
                                <?php $kapal->data_seek(0); while($k = $kapal->fetch_assoc()): ?>
                                    <option value="<?= $k['id'] ?>"><?= htmlspecialchars($k['nama_kapal']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-row" style="gap: 10px;">
                            <div class="form-group" style="flex: 1;">
                                <label>Asal</label>
                                <select name="asal_id" required>
                                    <option value="">-- Asal --</option>
                                    <?php $pelabuhan->data_seek(0); while($p = $pelabuhan->fetch_assoc()): ?>
                                        <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nama']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group" style="flex: 1;">
                                <label>Tujuan</label>
                                <select name="tujuan_id" required>
                                    <option value="">-- Tujuan --</option>
                                    <?php $pelabuhan->data_seek(0); while($p = $pelabuhan->fetch_assoc()): ?>
                                        <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nama']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-row" style="gap: 10px;">
                            <div class="form-group" style="flex: 1;">
                                <label>Tanggal</label>
                                <input type="date" name="tanggal" required>
                            </div>
                            <div class="form-group" style="flex: 1;">
                                <label>Jam</label>
                                <input type="time" name="jam" required>
                            </div>
                        </div>
                        <button type="submit" name="tambah" class="btn-primary">+ Simpan Jadwal</button>
                    </form>
                </div>

                <!-- FORM TAMBAH MINGGUAN (OTOMATIS) -->
                <div class="card" style="flex: 1; min-width: 300px; border: 2px solid #0B2E6F;">
                    <h3 style="color: #0B2E6F;">🚀 Buat Jadwal Mingguan (Otomatis)</h3>
                    <p style="font-size: 12px; color: #666; margin-bottom: 15px;">Isi data di bawah, centang hari yang diinginkan, dan sistem akan membuat jadwal untuk 1 minggu ke depan.</p>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        
                        <div class="form-group">
                            <label>Prefix Kode Voyage</label>
                            <input type="text" name="prefix_voyage" placeholder="Misal: NAK (Hasil: NAK-YYMMDD)" required>
                        </div>
                        <div class="form-group">
                            <label>Pilih Kapal</label>
                            <select name="kapal_id_mingguan" required>
                                <option value="">-- Pilih Kapal --</option>
                                <?php $kapal->data_seek(0); while($k = $kapal->fetch_assoc()): ?>
                                    <option value="<?= $k['id'] ?>"><?= htmlspecialchars($k['nama_kapal']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-row" style="gap: 10px;">
                            <div class="form-group" style="flex: 1;">
                                <label>Asal</label>
                                <select name="asal_id_mingguan" required>
                                    <option value="">-- Asal --</option>
                                    <?php $pelabuhan->data_seek(0); while($p = $pelabuhan->fetch_assoc()): ?>
                                        <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nama']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group" style="flex: 1;">
                                <label>Tujuan</label>
                                <select name="tujuan_id_mingguan" required>
                                    <option value="">-- Tujuan --</option>
                                    <?php $pelabuhan->data_seek(0); while($p = $pelabuhan->fetch_assoc()): ?>
                                        <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nama']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-row" style="gap: 10px;">
                            <div class="form-group" style="flex: 1;">
                                <label>Tanggal Mulai</label>
                                <input type="date" name="tgl_mulai" required>
                            </div>
                            <div class="form-group" style="flex: 1;">
                                <label>Jam</label>
                                <input type="time" name="jam_mingguan" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Pilih Hari Keberangkatan</label>
                            <!-- PERBAIKAN WARNA TEKS CHECKBOX -->
                            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 5px; background: #f9f9f9; padding: 10px; border-radius: 8px;">
                                <label style="font-weight: normal; cursor: pointer; color: #333; display: flex; align-items: center; gap: 5px;"><input type="checkbox" name="hari[]" value="1"> Senin</label>
                                <label style="font-weight: normal; cursor: pointer; color: #333; display: flex; align-items: center; gap: 5px;"><input type="checkbox" name="hari[]" value="2"> Selasa</label>
                                <label style="font-weight: normal; cursor: pointer; color: #333; display: flex; align-items: center; gap: 5px;"><input type="checkbox" name="hari[]" value="3"> Rabu</label>
                                <label style="font-weight: normal; cursor: pointer; color: #333; display: flex; align-items: center; gap: 5px;"><input type="checkbox" name="hari[]" value="4"> Kamis</label>
                                <label style="font-weight: normal; cursor: pointer; color: #333; display: flex; align-items: center; gap: 5px;"><input type="checkbox" name="hari[]" value="5"> Jumat</label>
                                <label style="font-weight: normal; cursor: pointer; color: #333; display: flex; align-items: center; gap: 5px;"><input type="checkbox" name="hari[]" value="6"> Sabtu</label>
                                <label style="font-weight: normal; cursor: pointer; color: #333; display: flex; align-items: center; gap: 5px; grid-column: span 2;"><input type="checkbox" name="hari[]" value="7"> Minggu</label>
                            </div>
                        </div>

                        <button type="submit" name="tambah_mingguan" class="btn-primary" style="background: #0B2E6F;">🚀 Generate Jadwal Mingguan</button>
                    </form>
                </div>
            </div>

            <!-- DAFTAR JADWAL -->
            <div class="card" style="margin-top: 20px;">
                <h3>Daftar Jadwal Keberangkatan</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Kode Voy</th>
                                <th>Kapal & Rute</th>
                                <th>Jadwal</th>
                                <th>Sisa Kursi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()): 
                                    $sisa_eko = $row['kapasitas_ekonomi'] - $row['terjual_eko'];
                                    $sisa_bis = $row['kapasitas_bisnis'] - $row['terjual_bis'];
                                ?>
                                <tr>
                                    <td><b><?= htmlspecialchars($row['kode_voyage']) ?></b></td>
                                    <td>
                                        <b><?= htmlspecialchars($row['nama_kapal']) ?></b><br>
                                        <small><?= htmlspecialchars($row['asal_nama']) ?> ➔ <?= htmlspecialchars($row['tujuan_nama']) ?></small>
                                    </td>
                                    <td>
                                        <?= date('d M Y', strtotime($row['tanggal'])) ?><br>
                                        <small style="color: #666;">Jam: <?= date('H:i', strtotime($row['jam_berangkat'])) ?></small>
                                    </td>
                                    <td>
                                        <span style="font-size: 12px; color: <?= $sisa_eko <= 0 ? 'red' : 'green' ?>;">Eko: <?= $sisa_eko ?> / <?= $row['kapasitas_ekonomi'] ?></span><br>
                                        <?php if($row['kapasitas_bisnis'] > 0): ?>
                                        <span style="font-size: 12px; color: <?= $sisa_bis <= 0 ? 'red' : 'green' ?>;">Bisnis: <?= $sisa_bis ?> / <?= $row['kapasitas_bisnis'] ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="white-space: nowrap;">
                                        <a href="manifest.php?id=<?= $row['id'] ?>" target="_blank" class="btn-primary" style="background: #0d47a1; padding: 6px 12px; font-size: 12px; display: inline-block; width: auto; text-decoration: none;">🖨️ Manifest</a>
                                        <a href="?hapus=<?= $row['id'] ?>" class="btn-danger" onclick="return confirm('Yakin ingin menghapus jadwal ini?')">🗑️ Hapus</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" style="text-align:center;">Belum ada jadwal voyage.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</body>
</html>
