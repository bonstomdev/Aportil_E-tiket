<?php
require_once 'config.php';
checkAuth(); checkAdmin(); checkAdmin(); // Hanya Admin yang login yang bisa backup

$tanggal = date('Y-m-d_H-i');
$nama_file = "backup_aportil_" . $tanggal . ".sql";

// Kumpulkan semua nama tabel
$tables = [];
$result = $mysqli->query("SHOW TABLES");
while ($row = $result->fetch_row()) {
    $tables[] = $row[0];
}

$return = "-- APORTIL FERRY DATABASE BACKUP\n";
$return .= "-- Generated: " . date('d M Y H:i:s') . "\n\n";
$return .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
$return .= "SET time_zone = \"+00:00\";\n\n";

// Looping setiap tabel untuk diambil strukturnya dan datanya
foreach ($tables as $table) {
    $result = $mysqli->query("SELECT * FROM $table");
    $num_fields = $result->field_count;

    // Hapus tabel lama jika ada (saat proses restore)
    $return .= "DROP TABLE IF EXISTS `$table`;\n";
    
    // Ambil struktur tabel (CREATE TABLE)
    $row2 = $mysqli->query("SHOW CREATE TABLE $table")->fetch_row();
    $return .= $row2[1] . ";\n\n";

    // Ambil datanya (INSERT INTO)
    for ($i = 0; $i < $num_fields; $i++) {
        while ($row = $result->fetch_row()) {
            $return .= "INSERT INTO `$table` VALUES(";
            for ($j = 0; $j < $num_fields; $j++) {
                $row[$j] = addslashes($row[$j]);
                $row[$j] = str_replace("\n", "\\n", $row[$j]);
                if (isset($row[$j])) {
                    $return .= '"' . $row[$j] . '"';
                } else {
                    $return .= '""';
                }
                if ($j < ($num_fields - 1)) {
                    $return .= ',';
                }
            }
            $return .= ");\n";
        }
    }
    $return .= "\n\n";
}

// Set header agar browser otomatis mendownload sebagai file .sql
header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename="' . $nama_file . '"');
header('Pragma: no-cache');
header('Expires: 0');

echo $return;
exit;
?>
