<?php
require_once 'config.php';
checkAuth();

$msg = '';
$status_scan = '';

// Proses ketika QR Code berhasil di-scan (dikirim via AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['kode_booking'])) {
    $kode = trim($_POST['kode_booking']);
    
    $sql = "SELECT b.id, b.status, t.status_boarding, t.nama_penumpang, v.kode_voyage, k.nama_kapal
            FROM booking b
            JOIN tiket t ON b.id = t.booking_id
            JOIN voyage v ON b.voyage_id = v.id
            JOIN kapal k ON v.kapal_id = k.id
            WHERE b.kode_booking = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('s', $kode);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$data) {
        $status_scan = 'error';
        $msg = "❌ Tiket <b>$kode</b> tidak ditemukan di sistem!";
    } elseif ($data['status'] != 'Paid') {
        $status_scan = 'error';
        $msg = "❌ Tiket <b>$kode</b> belum dibayar/diverifikasi (Status: PENDING).";
    } elseif ($data['status_boarding'] == 1) {
        $status_scan = 'error';
        $msg = "⚠️ Tiket <b>$kode</b> sudah pernah di-scan (Sudah Boarding)!";
    } else {
        // Update status boarding
        $upd = $mysqli->prepare("UPDATE tiket SET status_boarding = 1 WHERE booking_id = ?");
        $upd->bind_param('i', $data['id']);
        $upd->execute(); catatLog('Boarding', 'Tamu ' . $data['nama_penumpang'] . ' boarding di ' . $data['kode_voyage']);
        $upd->close();

        $status_scan = 'success';
        $msg = "✅ BERHASIL! Penumpang <b>" . htmlspecialchars($data['nama_penumpang']) . "</b> silakan naik ke kapal <b>" . htmlspecialchars($data['nama_kapal']) . "</b> (Voy: " . htmlspecialchars($data['kode_voyage']) . ").";
    }
    exit(json_encode(['status' => $status_scan, 'msg' => $msg]));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scan QR - APORTIL</title>
    <link rel="stylesheet" href="style.css">
    <!-- Library untuk Scanner Kamera -->
    <script src="https://unpkg.com/html5-qrcode"></script>
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="kapal.php">⚓ Master Pelabuhan
            <a href="kapal.php">🚢 Master Kapal</a></a>
            <a href="rute.php">🗺️ Master Rute</a>
            <a href="voyage.php">⏰ Jadwal Voyage</a>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php" class="active">📷 Scan QR</a>
            <a href="laporan.php">📑 Laporan
            <a href="z_report.php">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a>
            <a href="profil.php">🏢 Profil Perusahaan</a></a>
            <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
        </div>

        <div class="main-content">
            <h2>Scan E-Ticket (Boarding)</h2>
            <p>Arahkan kamera ke QR Code yang ada di layar HP atau kertas tiket penumpang.</p>
            
            <div id="result-box" style="display:none; padding: 20px; border-radius: 8px; margin-bottom: 20px; font-size: 18px; font-weight: bold; text-align: center;"></div>

            <div class="card">
                <div id="reader" style="width: 100%; max-width: 500px; margin: 0 auto;"></div>
            </div>
        </div>
    </div>

    <script>
        function onScanSuccess(decodedText, decodedResult) {
            // Hentikan scanner sementara
            html5QrcodeScanner.clear();
            document.getElementById('reader').innerHTML = "<h3 style='text-align:center;'>Memproses tiket...</h3>";

            // Kirim kode ke PHP
            fetch('scan.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'kode_booking=' + encodeURIComponent(decodedText)
            })
            .then(response => response.json())
            .then(data => {
                let box = document.getElementById('result-box');
                box.style.display = 'block';
                box.innerHTML = data.msg;
                
                if (data.status === 'success') {
                    box.style.background = '#e8f5e9';
                    box.style.color = '#2e7d32';
                    box.style.border = '2px solid #2e7d32';
                } else {
                    box.style.background = '#ffebee';
                    box.style.color = '#d32f2f';
                    box.style.border = '2px solid #d32f2f';
                }

                // Tampilkan tombol untuk scan lagi setelah 3 detik
                setTimeout(() => {
                    location.reload();
                }, 4000);
            });
        }

        let html5QrcodeScanner = new Html5QrcodeScanner(
            "reader", { fps: 10, qrbox: {width: 250, height: 250} }
        );
        html5QrcodeScanner.render(onScanSuccess);
    </script>
</body>
</html>
