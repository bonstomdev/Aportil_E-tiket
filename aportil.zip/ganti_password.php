<?php
require_once 'config.php';
checkAuth();

$msg_user = '';
$msg_pass = '';
$msg_kode = '';
$type_user = '';
$type_pass = '';
$type_kode = '';

$user_id = $_SESSION['user_id'];

// === PROSES GANTI USERNAME ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ubah_username'])) {
    $username_baru = trim($_POST['username_baru']);
    if (strlen($username_baru) < 4) {
        $msg_user = "Username minimal 4 karakter!"; $type_user = "alert-error";
    } else {
        $cek = $mysqli->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $cek->bind_param('si', $username_baru, $user_id);
        $cek->execute();
        if ($cek->get_result()->num_rows > 0) {
            $msg_user = "Username sudah digunakan!"; $type_user = "alert-error";
        } else {
            $upd = $mysqli->prepare("UPDATE users SET username = ? WHERE id = ?");
            $upd->bind_param('si', $username_baru, $user_id);
            if ($upd->execute()) {
                $_SESSION['username'] = $username_baru; 
                $msg_user = "Username berhasil diubah menjadi: <b>" . htmlspecialchars($username_baru) . "</b>"; $type_user = "alert-success";
            }
            $upd->close();
        }
        $cek->close();
    }
}

// === PROSES GANTI PASSWORD ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ubah_password'])) {
    $pass_lama = $_POST['pass_lama'];
    $pass_baru = $_POST['pass_baru'];
    $konfirmasi = $_POST['konfirmasi'];

    $stmt = $mysqli->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!password_verify($pass_lama, $user['password'])) {
        $msg_pass = "Password lama salah!"; $type_pass = "alert-error";
    } elseif ($pass_baru !== $konfirmasi) {
        $msg_pass = "Konfirmasi password baru tidak cocok!"; $type_pass = "alert-error";
    } elseif (strlen($pass_baru) < 6) {
        $msg_pass = "Password baru minimal 6 karakter!"; $type_pass = "alert-error";
    } else {
        $new_hash = password_hash($pass_baru, PASSWORD_DEFAULT);
        $upd = $mysqli->prepare("UPDATE users SET password = ? WHERE id = ?");
        $upd->bind_param('si', $new_hash, $user_id);
        if ($upd->execute()) {
            $msg_pass = "Password berhasil diperbarui!"; $type_pass = "alert-success";
            catatLog("Ganti Password", "Admin mengubah password.");
        }
        $upd->close();
    }
}

// === PROSES GANTI KODE RAHASIA ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ubah_kode'])) {
    $kode_baru = trim($_POST['kode_baru']);
    if (strlen($kode_baru) < 6) {
        $msg_kode = "Kode rahasia minimal 6 karakter!"; $type_kode = "alert-error";
    } else {
        $new_hash = password_hash($kode_baru, PASSWORD_DEFAULT);
        $upd = $mysqli->prepare("UPDATE users SET kode_rahasia = ? WHERE id = ?");
        $upd->bind_param('si', $new_hash, $user_id);
        if ($upd->execute()) {
            $msg_kode = "Kode Rahasia berhasil disimpan! Gunakan ini jika Anda lupa password."; $type_kode = "alert-success";
            catatLog("Kode Rahasia", "Admin mengubah kode rahasia.");
        }
        $upd->close();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaturan Akun - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= ucfirst($_SESSION['role']) ?>)</span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="pelabuhan.php">⚓ Master Pelabuhan</a>
            <a href="kapal.php">🚢 Master Kapal</a>
            <a href="rute.php">🗺️ Master Rute</a>
            <a href="voyage.php">⏰ Jadwal Voyage</a>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <a href="laporan.php">📑 Laporan</a>
            <a href="z_report.php">🧾 Z-Report Kasir</a>
            <a href="voucher.php">🎟️ Voucher Promo</a>
            <a href="profil.php">🏢 Profil Perusahaan</a>
            <a href="users.php">👥 Manajemen Pegawai</a>
            <a href="log.php">🕵️‍♂️ Log Aktivitas</a>
            <a href="ganti_password.php" class="active">⚙️ Pengaturan Akun</a>
            <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
        </div>

        <div class="main-content">
            <h2>Pengaturan Akun</h2>
            <p>Kelola Username, Password, dan Kode Rahasia Anda.</p>
            
            <div class="form-row">
                <!-- CARD GANTI USERNAME -->
                <div class="card" style="flex: 1; min-width: 300px;">
                    <h3>👤 Ubah Username</h3>
                    <?php if($msg_user): ?><div class="<?= $type_user ?>" style="margin-bottom: 15px;"><?= $msg_user ?></div><?php endif; ?>
                    <form method="POST">
                        <div class="form-group">
                            <label>Username Saat Ini</label>
                            <input type="text" value="<?= htmlspecialchars($_SESSION['username']) ?>" disabled style="background:#eee; color:#666;">
                        </div>
                        <div class="form-group">
                            <label>Username Baru</label>
                            <input type="text" name="username_baru" required placeholder="Masukkan username baru" minlength="4">
                        </div>
                        <button type="submit" name="ubah_username" class="btn-primary">Simpan Username</button>
                    </form>
                </div>

                <!-- CARD GANTI PASSWORD -->
                <div class="card" style="flex: 1; min-width: 300px;">
                    <h3>🔐 Ubah Password</h3>
                    <?php if($msg_pass): ?><div class="<?= $type_pass ?>" style="margin-bottom: 15px;"><?= $msg_pass ?></div><?php endif; ?>
                    <form method="POST">
                        <div class="form-group">
                            <label>Password Lama</label>
                            <input type="password" name="pass_lama" required placeholder="Masukkan password saat ini">
                        </div>
                        <div class="form-group">
                            <label>Password Baru (Min. 6 Karakter)</label>
                            <input type="password" name="pass_baru" required placeholder="Masukkan password baru" minlength="6">
                        </div>
                        <div class="form-group">
                            <label>Konfirmasi Password Baru</label>
                            <input type="password" name="konfirmasi" required placeholder="Ketik ulang password baru">
                        </div>
                        <button type="submit" name="ubah_password" class="btn-primary">Simpan Password</button>
                    </form>
                </div>
            </div>

            <!-- CARD KODE RAHASIA -->
            <div class="card" style="margin-top: 20px; border-left: 5px solid #ff9800;">
                <h3>🗝️ Kode Rahasia (Untuk Lupa Password)</h3>
                <p style="font-size: 13px; color: #666; margin-bottom: 15px;">Simpan kode ini di tempat aman. Jika Anda lupa password login, Anda bisa meresetnya sendiri menggunakan kode ini.</p>
                <?php if($msg_kode): ?><div class="<?= $type_kode ?>" style="margin-bottom: 15px;"><?= $msg_kode ?></div><?php endif; ?>
                <form method="POST">
                    <div class="form-row">
                        <div class="form-group" style="flex: 2;">
                            <label>Kode Rahasia Baru</label>
                            <input type="text" name="kode_baru" required placeholder="Misal: RAHASIAAPORTIL2026" minlength="6">
                        </div>
                        <div class="form-group" style="flex: 1; display: flex; align-items: flex-end;">
                            <button type="submit" name="ubah_kode" class="btn-primary" style="background: #ff9800; margin: 0; width: 100%;">Simpan Kode</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
