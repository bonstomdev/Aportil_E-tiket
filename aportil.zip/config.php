<?php
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Lax');
ini_set('display_errors', 0); 
ini_set('log_errors', 1); 
error_reporting(E_ALL);

session_start();

if (isset($_GET['lang'])) {
    $allowed_lang = ['tet', 'id', 'en'];
    if (in_array($_GET['lang'], $allowed_lang)) {
        $_SESSION['lang'] = $_GET['lang'];
    }
}
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'tet'; 
}

require_once 'lang.php';

function __($key) {
    global $translations;
    $lang = $_SESSION['lang'];
    return $translations[$lang][$key] ?? $key;
}

$host = '127.0.0.1';
$user = 'root';
$pass = '';
$db   = 'aportil_ferry';

$mysqli = new mysqli($host, $user, $pass, $db);
if ($mysqli->connect_error) {
    error_log("DB Error: " . $mysqli->connect_error);
    die("Koneksi database gagal.");
}
$mysqli->set_charset('utf8mb4');

$SETTINGS = [];
$res_set = $mysqli->query("SELECT nama_key, nilai FROM pengaturan");
if ($res_set) {
    while ($row_set = $res_set->fetch_assoc()) {
        $SETTINGS[$row_set['nama_key']] = $row_set['nilai'];
    }
}

function checkAuth() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

function checkAdmin() {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        echo "<script>alert('Akses Ditolak! Halaman ini hanya untuk Admin.'); window.location='index.php';</script>";
        exit;
    }
}

// === FUNGSI BARU: CATAT LOG AKTIVITAS ===
function catatLog($aksi, $keterangan = '') {
    global $mysqli;
    $u = $_SESSION['username'] ?? 'System';
    $stmt = $mysqli->prepare("INSERT INTO log_aktivitas (username, aksi, keterangan) VALUES (?, ?, ?)");
    $stmt->bind_param('sss', $u, $aksi, $keterangan);
    $stmt->execute();
    $stmt->close();
}
// =========================================

function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken($token) {
    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        die("Error Keamanan: Token tidak valid.");
    }
}

if (isset($_SESSION['user_id'])) {
    $q_auto_cancel = $mysqli->query("
        UPDATE booking 
        SET status = 'Cancelled' 
        WHERE status = 'Pending' 
        AND created_at < NOW() - INTERVAL 2 HOUR
    ");
    if ($mysqli->affected_rows > 0) {
        $_SESSION['auto_cancel_count'] = $mysqli->affected_rows;
    }
}

if (basename($_SERVER['PHP_SELF']) == 'config.php') {
    header('HTTP/1.0 403 Forbidden');
    exit('Akses ditolak.');
}
?>
