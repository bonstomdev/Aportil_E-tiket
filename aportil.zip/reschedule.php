<?php
require_once 'config.php';
checkAuth();

$id = (int)($_GET['id'] ?? 0);
$msg = '';

// Ambil data booking saat ini
$sql = "SELECT b.*, v.kode_voyage, v.tanggal, v.jam_berangkat, v.pelabuhan_asal_id, v.pelabuhan_tujuan_id, 
        k.nama_kapal, p1.nama as asal, p2.nama as tujuan
        FROM booking b
        JOIN voyage v ON b.voyage_id = v.id
        JOIN kapal k ON v.kapal_id = k.id
        JOIN pelabuhan p1 ON v.pelabuhan_asal_id = p1.id
        JOIN pelabuhan p2 ON v.pelabuhan_tujuan_id = p2.id
        WHERE b.id = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param('i', $id);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    die("<h2 style='text-align:center; margin-top:50px;'>Data Booking tidak ditemukan.</h2>");
}

// Ambil jumlah penumpang dan kelas
$stmt_pax = $mysqli->prepare("SELECT kelas, COUNT(*) as jml FROM tiket WHERE booking_id = ? GROUP BY kelas");
$stmt_pax->bind_param('i', $id);
$stmt_pax->execute();
$pax_data = $stmt_pax->get_result()->fetch_assoc();
$stmt_pax->close();

$jumlah_pax = $pax_data['jml'] ?? 0;
$kelas = $pax_data['kelas'] ?? 'Ekonomi';

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['proses_reschedule'])) {
    $voyage_baru_id = (int)$_POST['voyage_baru'];

    // Cek kuota voyage baru
    $sql_cek = "SELECT v.*, k.kapasitas_ekonomi, k.kapasitas_bisnis,
                (SELECT COUNT(t.id) FROM tiket t JOIN booking b2 ON t.booking_id = b2.id WHERE b2.voyage_id = v.id AND b2.status != 'Cancelled' AND t.kelas = 'Ekonomi') as terjual_eko,
                (SELECT COUNT(t.id) FROM tiket t JOIN booking b2 ON t.booking_id = b2.id WHERE b2.voyage_id = v.id AND b2.status != 'Cancelled' AND t.kelas = 'Bisnis') as terjual_bis
                FROM voyage v JOIN kapal k ON v.kapal_id = k.id WHERE v.id = ?";
    $stmt_cek = $mysqli->prepare($sql_cek);
    $stmt_cek->bind_param('i', $voyage_baru_id);
    $stmt_cek->execute();
    $v_baru = $stmt_cek->get_result()->fetch_assoc();
    $stmt_cek->close();

    $sisa_kursi = ($kelas == 'Ekonomi') ? ($v_baru['kapasitas_ekonomi'] - $v_baru['terjual_eko']) : ($v_baru['kapasitas_bisnis'] - $v_baru['terjual_bis']);

    if ($sisa_kursi >= $jumlah_pax) {
        // Update voyage_id di tabel booking
        $upd = $mysqli->prepare("UPDATE booking SET voyage_id = ? WHERE id = ?");
        $upd->bind_param('ii', $voyage_baru_id, $id);
        if ($upd->execute()) {
            $msg = "<div class='alert-success'>✅ Tiket berhasil dipindahkan ke jadwal baru! Silakan cek E-Ticket terbaru.</div>"; catatLog('Reschedule', 'Tiket ' . $booking['kode_booking'] . ' dipindah jadwal');
            // Refresh data
            header("Refresh:2; url=verifikasi.php");
        }
        $upd->close();
    } else {
        $msg = "<div class='alert-error'>❌ Gagal! Kursi kelas $kelas di jadwal tujuan tidak cukup (Sisa: $sisa_kursi).</div>";
    }
}

// Ambil daftar voyage baru dengan rute yang sama dan tanggal hari ini atau ke depan
$hari_ini = date('Y-m-d');
$sql_v = "SELECT v.*, k.nama_kapal,
          (SELECT COUNT(t.id) FROM tiket t JOIN booking b2 ON t.booking_id = b2.id WHERE b2.voyage_id = v.id AND b2.status != 'Cancelled' AND t.kelas = 'Ekonomi') as terjual_eko,
          (SELECT COUNT(t.id) FROM tiket t JOIN booking b2 ON t.booking_id = b2.id WHERE b2.voyage_id = v.id AND b2.status != 'Cancelled' AND t.kelas = 'Bisnis') as terjual_bis
          FROM voyage v 
          JOIN kapal k ON v.kapal_id = k.id 
          WHERE v.pelabuhan_asal_id = ? AND v.pelabuhan_tujuan_id = ? AND v.tanggal >= ? AND v.id != ?
          ORDER BY v.tanggal ASC, v.jam_berangkat ASC";
$stmt_v = $mysqli->prepare($sql_v);
$stmt_v->bind_param('iisi', $booking['pelabuhan_asal_id'], $booking['pelabuhan_tujuan_id'], $hari_ini, $booking['voyage_id']);
$stmt_v->execute();
$result_v = $stmt_v->get_result();
$stmt_v->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reschedule Tiket - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="verifikasi.php" class="active">📥 Verifikasi Tiket</a>
            <a href="scan.php">📷 Scan QR</a>
            <a href="laporan.php">📑 Laporan
            <a href="z_report.php">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a>
            <a href="profil.php">🏢 Profil Perusahaan</a></a></a>
            <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
            <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
        </div>

        <div class="main-content">
            <h2>🔄 Reschedule / Ganti Jadwal</h2>
            <p>Pindahkan tiket penumpang ke jadwal keberangkatan lain.</p>

            <?= $msg ?>

            <div class="form-row">
                <div class="card" style="flex: 1; min-width: 300px; border-left: 5px solid #d32f2f;">
                    <h3>Jadwal Saat Ini</h3>
                    <p><b>Kode Booking:</b> <?= htmlspecialchars($booking['kode_booking']) ?></p>
                    <p><b>Nama Pemesan:</b> <?= htmlspecialchars($booking['nama_pemesan']) ?></p>
                    <p><b>Rute:</b> <?= htmlspecialchars($booking['asal']) ?> ➔ <?= htmlspecialchars($booking['tujuan']) ?></p>
                    <p><b>Kapal:</b> <?= htmlspecialchars($booking['nama_kapal']) ?> (<?= $booking['kode_voyage'] ?>)</p>
                    <p><b>Jadwal:</b> <?= date('d M Y', strtotime($booking['tanggal'])) ?> | <?= date('H:i', strtotime($booking['jam_berangkat'])) ?></p>
                    <p><b>Jumlah Penumpang:</b> <?= $jumlah_pax ?> Orang (<?= $kelas ?>)</p>
                </div>

                <div class="card" style="flex: 1; min-width: 300px; border-left: 5px solid #2e7d32;">
                    <h3>Pilih Jadwal Baru</h3>
                    <form method="POST">
                        <div class="form-group">
                            <label>Jadwal Keberangkatan Tersedia (Rute Sama)</label>
                            <select name="voyage_baru" required>
                                <option value="">-- Pilih Jadwal Baru --</option>
                                <?php while($v = $result_v->fetch_assoc()): 
                                    $sisa = ($kelas == 'Ekonomi') ? ($v['kapasitas_ekonomi'] - $v['terjual_eko']) : ($v['kapasitas_bisnis'] - $v['terjual_bis']);
                                ?>
                                    <option value="<?= $v['id'] ?>" <?= $sisa < $jumlah_pax ? 'disabled' : '' ?>>
                                        <?= date('d M Y', strtotime($v['tanggal'])) ?> | <?= date('H:i', strtotime($v['jam_berangkat'])) ?> - <?= htmlspecialchars($v['nama_kapal']) ?> (<?= $v['kode_voyage'] ?>) 
                                        [Sisa Kursi: <?= $sisa ?>]
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <button type="submit" name="proses_reschedule" class="btn-primary" onclick="return confirm('Pindahkan tiket ke jadwal baru ini?')">🔄 Proses Reschedule</button>
                        <a href="verifikasi.php" class="btn-primary" style="background: #666; text-decoration: none; display: block; text-align: center; margin-top: 10px;">Batal</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
