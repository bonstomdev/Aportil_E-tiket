<?php
require_once 'config.php';
checkAuth();
checkAdmin(); // Hanya Admin yang bisa lihat log

$result = $mysqli->query("SELECT * FROM log_aktivitas ORDER BY waktu DESC LIMIT 200");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Aktivitas - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= ucfirst($_SESSION['role']) ?>)</span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="kapal.php">⚓ Master Pelabuhan
            <a href="kapal.php">🚢 Master Kapal</a></a>
            <a href="rute.php">🗺️ Master Rute</a>
            <a href="voyage.php">⏰ Jadwal Voyage</a>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <a href="laporan.php">📑 Laporan</a>
            <a href="z_report.php">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a></a>
            <a href="profil.php">🏢 Profil Perusahaan</a>
            <a href="users.php">👥 Manajemen Pegawai
            <a href="log.php">🕵️‍♂️ Log Aktivitas</a></a>
            <a href="log.php" class="active">🕵️‍♂️ Log Aktivitas</a>
            <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
            <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
        </div>

        <div class="main-content">
            <h2>Log Aktivitas Sistem</h2>
            <p>Catatan 200 aktivitas terakhir yang dilakukan oleh Admin dan Kasir.</p>

            <div class="card">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Waktu</th>
                                <th>Pengguna</th>
                                <th>Aksi</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td style="white-space: nowrap; font-size: 12px;"><?= date('d/m/y H:i:s', strtotime($row['waktu'])) ?></td>
                                    <td><b><?= htmlspecialchars($row['username']) ?></b></td>
                                    <td><span class="badge" style="background:#e0e7ff; color:#1e40af;"><?= htmlspecialchars($row['aksi']) ?></span></td>
                                    <td><?= htmlspecialchars($row['keterangan']) ?></td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="4" style="text-align:center;">Belum ada aktivitas tercatat.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
