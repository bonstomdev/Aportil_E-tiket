<?php
require_once 'config.php';
checkAuth();
checkAdmin();

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    verifyCsrfToken($_POST['csrf_token']);
    
    $fields = ['nama_perusahaan', 'alamat', 'no_rek_bnu', 'no_rek_bnctl', 'no_rek_mandiri', 'wa_admin'];
    
    $mysqli->begin_transaction();
    try {
        foreach ($fields as $f) {
            $val = trim($_POST[$f] ?? '');
            $stmt = $mysqli->prepare("UPDATE pengaturan SET nilai = ? WHERE nama_key = ?");
            $stmt->bind_param('ss', $val, $f);
            $stmt->execute();
            $stmt->close();
        }

        // Proses Upload Gambar QRIS (Jika ada)
        if (isset($_FILES['qris_image']) && $_FILES['qris_image']['error'] == 0) {
            $ext = strtolower(pathinfo($_FILES['qris_image']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png'])) {
                $new_name = 'qris_bank_' . time() . '.' . $ext;
                $target = 'uploads/' . $new_name;
                if (move_uploaded_file($_FILES['qris_image']['tmp_name'], $target)) {
                    $upd = $mysqli->prepare("UPDATE pengaturan SET nilai = ? WHERE nama_key = 'qris_image'");
                    $upd->bind_param('s', $new_name);
                    $upd->execute();
                    $upd->close();
                }
            }
        }

        $mysqli->commit();
        $msg = "<div class='alert-success'>✅ Profil Perusahaan berhasil diperbarui!</div>";
        
        // Refresh data settings
        $res_set = $mysqli->query("SELECT nama_key, nilai FROM pengaturan");
        while ($row_set = $res_set->fetch_assoc()) {
            $SETTINGS[$row_set['nama_key']] = $row_set['nilai'];
        }
    } catch (Exception $e) {
        $mysqli->rollback();
        $msg = "<div class='alert-error'>❌ Gagal menyimpan: " . $e->getMessage() . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Perusahaan - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= ucfirst($_SESSION['role']) ?>)</span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="kapal.php">⚓ Master Pelabuhan
            <a href="kapal.php">🚢 Master Kapal</a></a>
            <a href="rute.php">🗺️ Master Rute</a>
            <a href="voyage.php">⏰ Jadwal Voyage</a>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <a href="laporan.php">📑 Laporan</a>
            <a href="z_report.php">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a></a>
            <a href="profil.php" class="active">🏢 Profil Perusahaan</a>
            <a href="users.php">👥 Manajemen Pegawai</a>
            <a href="log.php">🕵️‍♂️ Log Aktivitas</a>
            <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
            <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
        </div>

        <div class="main-content">
            <h2>Profil Perusahaan</h2>
            <p>Pengaturan ini akan muncul secara otomatis di halaman penumpang, tiket, dan struk.</p>
            
            <?= $msg ?>

            <div class="card" style="max-width: 600px;">
                <h3>Data Instansi & Pembayaran</h3>
                <!-- TAMBAHKAN enctype UNTUK UPLOAD FILE -->
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    
                    <div class="form-group">
                        <label>Nama Perusahaan / Instansi</label>
                        <input type="text" name="nama_perusahaan" value="<?= htmlspecialchars($SETTINGS['nama_perusahaan'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Alamat / Sub-Judul</label>
                        <input type="text" name="alamat" value="<?= htmlspecialchars($SETTINGS['alamat'] ?? '') ?>" required>
                    </div>
                    
                    <h4 style="margin: 20px 0 10px 0; color: #0B2E6F; border-bottom: 1px solid #eee; padding-bottom: 5px;">Rekening Pembayaran</h4>
                    
                    <div class="form-group">
                        <label>No. Rekening BNU</label>
                        <input type="text" name="no_rek_bnu" value="<?= htmlspecialchars($SETTINGS['no_rek_bnu'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label>No. Rekening BNCTL</label>
                        <input type="text" name="no_rek_bnctl" value="<?= htmlspecialchars($SETTINGS['no_rek_bnctl'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label>No. Rekening Mandiri</label>
                        <input type="text" name="no_rek_mandiri" value="<?= htmlspecialchars($SETTINGS['no_rek_mandiri'] ?? '') ?>" required>
                    </div>
                    
                    <h4 style="margin: 20px 0 10px 0; color: #0B2E6F; border-bottom: 1px solid #eee; padding-bottom: 5px;">Gambar QRIS (Opsional)</h4>
                    
                    <?php if(!empty($SETTINGS['qris_image'])): ?>
                        <div style="margin-bottom: 15px;">
                            <img src="uploads/<?= htmlspecialchars($SETTINGS['qris_image']) ?>" style="max-width: 200px; border-radius: 8px; border: 1px solid #ccc; display: block;">
                            <small style="color: #666;">QRIS saat ini</small>
                        </div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label>Upload Gambar QRIS Baru (JPG/PNG)</label>
                        <input type="file" name="qris_image" accept="image/jpeg, image/png" style="padding: 10px; border: 1px dashed #0B2E6F; border-radius: 8px; width: 100%;">
                    </div>

                    <h4 style="margin: 20px 0 10px 0; color: #0B2E6F; border-bottom: 1px solid #eee; padding-bottom: 5px;">Kontak</h4>

                    <div class="form-group">
                        <label>No. WhatsApp Admin (Format: 670xxxxxx)</label>
                        <input type="text" name="wa_admin" value="<?= htmlspecialchars($SETTINGS['wa_admin'] ?? '') ?>" required>
                    </div>

                    <button type="submit" name="simpan" class="btn-primary" style="margin-top: 15px;">💾 Simpan Pengaturan</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
