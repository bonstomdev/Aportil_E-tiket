<?php
require_once 'config.php';
require_once 'negara.php';

$kode = $_GET['kode'] ?? '';
$msg = '';

if (!$kode) {
    die("<h2 style='text-align:center; margin-top:50px;'>Kode Booking tidak valid.</h2>");
}

// Ambil data booking
$stmt = $mysqli->prepare("SELECT id, status FROM booking WHERE kode_booking = ?");
$stmt->bind_param('s', $kode);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    die("<h2 style='text-align:center; margin-top:50px;'>Data Booking tidak ditemukan.</h2>");
}

// Cek status: Hanya boleh edit jika PENDING
if ($booking['status'] !== 'Pending') {
    die("<div style='max-width:500px;margin:50px auto;padding:20px;background:#ffebee;color:#d32f2f;border-radius:8px;text-align:center;font-family:sans-serif;'>
        <h2>❌ Data Terkunci</h2>
        <p>Tiket dengan status <b>" . htmlspecialchars($booking['status']) . "</b> tidak dapat diedit.</p>
        <p>Jika ada kesalahan, silakan hubungi Admin APORTIL.</p>
        <a href='tiket.php?kode=$kode' style='color:#0B2E6F; font-weight:bold;'>Kembali ke Tiket</a>
        </div>");
}

// Proses Simpan Perubahan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $tiket_ids = $_POST['tiket_id'] ?? [];
    $nama = $_POST['nama_penumpang'] ?? [];
    $ident = $_POST['no_identitas'] ?? [];
    $negara_arr = $_POST['negara'] ?? [];

    $mysqli->begin_transaction();
    try {
        for ($i = 0; $i < count($tiket_ids); $i++) {
            $tid = (int)$tiket_ids[$i];
            $nm = trim($nama[$i]);
            $idn = trim($ident[$i]);
            $ngr = trim($negara_arr[$i]);

            $stmt_upd = $mysqli->prepare("UPDATE tiket SET nama_penumpang = ?, no_identitas = ?, negara = ? WHERE id = ? AND booking_id = ?");
            $stmt_upd->bind_param('sssii', $nm, $idn, $ngr, $tid, $booking['id']);
            $stmt_upd->execute();
            $stmt_upd->close();
        }
        $mysqli->commit();
        $msg = "<div class='alert-success'>✅ Data penumpang berhasil diperbarui! Silakan cek tiket terbaru Anda.</div>";
        echo "<script>setTimeout(function(){ window.location='tiket.php?kode=$kode'; }, 2000);</script>";
    } catch (Exception $e) {
        $mysqli->rollback();
        $msg = "<div class='alert-error'>❌ Gagal menyimpan: " . $e->getMessage() . "</div>";
    }
}

// Ambil data tiket (penumpang)
$stmt2 = $mysqli->prepare("SELECT * FROM tiket WHERE booking_id = ? ORDER BY id ASC");
$stmt2->bind_param('i', $booking['id']);
$stmt2->execute();
$penumpangs = $stmt2->get_result();
$stmt2->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Penumpang - <?= htmlspecialchars($kode) ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background: #eef1f7;">
    <div style="max-width: 700px; margin: 30px auto; padding: 20px;">
        
        <div class="card" style="background: #fff3e0; border-left: 5px solid #ff9800; margin-bottom: 20px;">
            <h3 style="color: #e65100; margin: 0 0 5px 0;">⚠️ Perhatian</h3>
            <p style="margin: 0; font-size: 14px; color: #333;">Anda hanya bisa mengedit data selama tiket masih berstatus <b>PENDING</b> (belum dibayar). Pastikan penulisan nama dan nomor identitas sudah benar sesuai KTP/Passport.</p>
        </div>

        <?= $msg ?>

        <div class="card">
            <h2 style="color: var(--primary); margin-bottom: 5px;">✏️ Edit Data Penumpang</h2>
            <p style="color: #666; font-size: 13px; margin-bottom: 20px;">Kode Booking: <b><?= htmlspecialchars($kode) ?></b></p>

            <form method="POST">
                <?php $no=1; while($p = $penumpangs->fetch_assoc()): ?>
                    <div style="background: #f9f9f9; padding: 15px; border-radius: 8px; margin-bottom: 15px; border-left: 4px solid #0B2E6F;">
                        <h4 style="margin-bottom: 10px; color: var(--primary); font-size: 14px;">Penumpang <?= $no++ ?> (Kelas: <?= $p['kelas'] ?>)</h4>
                        <input type="hidden" name="tiket_id[]" value="<?= $p['id'] ?>">
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Nama Lengkap</label>
                                <input type="text" name="nama_penumpang[]" value="<?= htmlspecialchars($p['nama_penumpang']) ?>" required>
                            </div>
                            <div class="form-group">
                                <label>No. Identitas (KTP/Passport)</label>
                                <input type="text" name="no_identitas[]" value="<?= htmlspecialchars($p['no_identitas']) ?>" required>
                            </div>
                        </div>
                        
                        <div class="form-group" style="margin-bottom: 0;">
                            <label>Negara / Country</label>
                            <select name="negara[]" required>
                                <?php foreach($daftar_negara as $neg): ?>
                                    <option value="<?= $neg ?>" <?= $p['negara'] == $neg ? 'selected' : '' ?>><?= $neg ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                <?php endwhile; ?>

                <div style="display: flex; gap: 10px;">
                    <button type="submit" name="simpan" class="btn-primary" style="flex: 2; background: #2e7d32;">💾 Simpan Perubahan</button>
                    <a href="tiket.php?kode=<?= $kode ?>" class="btn-primary" style="flex: 1; background: #666; text-decoration: none; text-align: center;">Batal</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
