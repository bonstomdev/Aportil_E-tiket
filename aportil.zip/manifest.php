<?php
require_once 'config.php';
checkAuth();

$voyage_id = (int)($_GET['id'] ?? 0);

$sql = "SELECT v.*, k.nama_kapal, p1.nama as asal, p2.nama as tujuan 
        FROM voyage v 
        JOIN kapal k ON v.kapal_id = k.id 
        JOIN pelabuhan p1 ON v.pelabuhan_asal_id = p1.id 
        JOIN pelabuhan p2 ON v.pelabuhan_tujuan_id = p2.id 
        WHERE v.id = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param('i', $voyage_id);
$stmt->execute();
$v = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$v) {
    die("<h2 style='text-align:center; margin-top:50px;'>Voyage tidak ditemukan.</h2>");
}

$sql2 = "SELECT t.*, b.kode_booking FROM tiket t JOIN booking b ON t.booking_id = b.id WHERE b.voyage_id = ? AND b.status = 'Paid' ORDER BY t.nama_penumpang ASC";
$stmt2 = $mysqli->prepare($sql2);
$stmt2->bind_param('i', $voyage_id);
$stmt2->execute();
$tickets = $stmt2->get_result();
$stmt2->close();

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $filename = "Manifest_" . $v['kode_voyage'] . "_" . $v['tanggal'] . ".csv";
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    fputcsv($output, ['No', 'Nama Penumpang', 'No. Identitas', 'Negara', 'Kelas', 'Kendaraan', 'Plat Nomor', 'Kargo (Koli)', 'Deskripsi Kargo']);
    $no = 1;
    $mysqli2 = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $stmt_export = $mysqli2->prepare($sql2);
    $stmt_export->bind_param('i', $voyage_id);
    $stmt_export->execute();
    $res_export = $stmt_export->get_result();
    while($t = $res_export->fetch_assoc()) {
        fputcsv($output, [ $no++, $t['nama_penumpang'], $t['no_identitas'], $t['negara'] ?? 'Timor-Leste', $t['kelas'], $t['jenis_kendaraan'], $t['plat_nomor'], $t['jumlah_kargo'], $t['deskripsi_kargo'] ]);
    }
    fclose($output);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manifest Kapal - <?= $v['kode_voyage'] ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { padding: 20px; background: var(--bg); color: var(--text); }
        .container { background: var(--white); padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); max-width: 1000px; margin: 0 auto; border: 1px solid var(--border); }
        .header { text-align: center; border-bottom: 2px solid var(--text); padding-bottom: 10px; margin-bottom: 20px; }
        .header h2 { margin: 0; font-size: 24px; color: var(--text); }
        .header p { margin: 5px 0; font-size: 14px; color: var(--text); opacity: 0.8; }
        .info { display: flex; justify-content: space-between; margin-bottom: 20px; font-size: 14px; color: var(--text); }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th, td { border: 1px solid var(--border); padding: 8px; text-align: left; color: var(--text); }
        th { background-color: var(--table-th); }
        .btn-group { display: flex; gap: 10px; justify-content: center; margin-bottom: 20px; }
        .btn { padding: 10px 20px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; text-decoration: none; color: white; font-weight: bold; }
        .btn-print { background: var(--primary); }
        .btn-excel { background: #2e7d32; }
        .btn-back { background: #666; }
    </style>
</head>
<body>
    <div class="container">
        <div class="btn-group">
            <button onclick="window.print()" class="btn btn-print">🖨️ Cetak Manifest</button>
            <a href="?id=<?= $voyage_id ?>&export=csv" class="btn btn-excel">📊 Download Excel</a>
            <a href="voyage.php" class="btn btn-back">← Kembali</a>
        </div>

        <div class="header">
            <h2>APORTIL, I.P.</h2>
            <p>MANIFEST PENUMPANG KAPAL</p>
        </div>

        <div class="info">
            <div>
                <b>Kapal:</b> <?= htmlspecialchars($v['nama_kapal']) ?><br>
                <b>Voyage:</b> <?= htmlspecialchars($v['kode_voyage']) ?>
            </div>
            <div style="text-align: right;">
                <b>Rute:</b> <?= htmlspecialchars($v['asal']) ?> ➔ <?= htmlspecialchars($v['tujuan']) ?><br>
                <b>Jadwal:</b> <?= date('d M Y', strtotime($v['tanggal'])) ?> - <?= date('H:i', strtotime($v['jam_berangkat'])) ?>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Penumpang</th>
                    <th>No. Identitas</th>
                    <th>Negara</th>
                    <th>Kelas</th>
                    <th>Kendaraan</th>
                    <th>Kargo</th>
                </tr>
            </thead>
            <tbody>
                <?php if($tickets->num_rows > 0): ?>
                    <?php $no=1; while($t = $tickets->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($t['nama_penumpang']) ?></td>
                        <td><?= htmlspecialchars($t['no_identitas']) ?></td>
                        <td><?= htmlspecialchars($t['negara'] ?? 'Timor-Leste') ?></td>
                        <td><?= $t['kelas'] ?></td>
                        <td><?= $t['jenis_kendaraan'] != 'Tidak Ada' ? $t['jenis_kendaraan'].' ('.$t['plat_nomor'].')' : '-' ?></td>
                        <td><?= $t['jumlah_kargo'] > 0 ? $t['jumlah_kargo'].' Koli - '.htmlspecialchars($t['deskripsi_kargo'] ?? '-') : '-' ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="7" style="text-align:center;">Belum ada penumpang terverifikasi untuk Voyage ini.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
