<?php
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Syarat & Ketentuan - APORTIL Ferry</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .legal-container { max-width: 800px; margin: 40px auto; padding: 30px; background: var(--white); border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid var(--border); }
        .legal-container h1 { color: var(--primary); margin-bottom: 10px; text-align: center; }
        .legal-container p.subtitle { text-align: center; color: var(--text); opacity: 0.7; margin-bottom: 30px; font-size: 14px; }
        .legal-container h2 { color: var(--primary); font-size: 18px; margin-top: 25px; margin-bottom: 10px; border-bottom: 1px solid var(--border); padding-bottom: 5px; }
        .legal-container p, .legal-container li { font-size: 14px; line-height: 1.6; color: var(--text); margin-bottom: 10px; }
        .legal-container ul { padding-left: 20px; margin-bottom: 15px; }
        .btn-back { display: inline-block; margin-top: 30px; padding: 12px 25px; background: var(--primary); color: white; text-decoration: none; border-radius: 8px; font-weight: bold; }
    </style>
</head>
<body style="background: var(--bg);">

    <nav class="navbar" style="background: var(--primary); display: flex; justify-content: space-between; align-items: center; padding: 10px 15px;">
        <div class="logo" style="font-weight: bold; color: white;">⚓ <?= htmlspecialchars($SETTINGS['nama_perusahaan'] ?? 'APORTIL Ferry') ?></div>
        <a href="pesan.php" style="color: white; text-decoration: none; font-size: 14px; background: rgba(255,255,255,0.2); padding: 6px 12px; border-radius: 5px;">← Kembali ke Beranda</a>
    </nav>

    <div class="legal-container">
        <h1>📜 Syarat & Ketentuan</h1>
        <p class="subtitle">Terakhir Diperbarui: <?= date('d F Y') ?></p>

        <p>Selamat datang di Sistem Informasi Tiket Feri <b><?= htmlspecialchars($SETTINGS['nama_perusahaan'] ?? 'APORTIL, I.P.') ?></b>. Dengan menggunakan layanan kami, Anda dianggap telah membaca, memahami, dan menyetujui seluruh syarat dan ketentuan di bawah ini.</p>

        <h2>1. Ketentuan Pembelian Tiket</h2>
        <ul>
            <li>Penumpang wajib mengisi data diri (Nama, No. Identitas, dan Negara) dengan benar dan sesuai dengan dokumen resmi (KTP/Passport).</li>
            <li>Satu Kode Booking dapat digunakan untuk beberapa penumpang sekaligus (keluarga/grup).</li>
            <li>Tiket yang sudah dibeli tidak dapat dipindahtangankan kepada orang lain tanpa persetujuan Admin.</li>
        </ul>

        <h2>2. Pembayaran</h2>
        <ul>
            <li>Pembayaran dapat dilakukan melalui Transfer Bank atau Scan QRIS yang tertera pada halaman checkout.</li>
            <li>Penumpang wajib mengunggah bukti transfer yang sah. Jika dalam waktu <b>2 Jam</b> belum dibayar, pesanan akan otomatis dibatalkan oleh sistem.</li>
        </ul>

        <h2>3. Pembatalan & Pengembalian Dana (Refund)</h2>
        <ul>
            <li>Pembatalan tiket dapat dilakukan secara mandiri melalui menu "Cek Tiket" sebelum jadwal keberangkatan.</li>
            <li>Pengembalian dana (Refund) sepenuhnya menjadi kebijakan manajemen APORTIL. Silakan hubungi loket/petugas untuk proses lebih lanjut.</li>
        </ul>

        <h2>4. Kebijakan Privasi (Data Pribadi)</h2>
        <ul>
            <li>Kami mengumpulkan data pribadi seperti Nama, Nomor HP, dan Foto Identitas (KTP/Passport) <b>semata-mata untuk keperluan manifest kapal dan keselamatan pelayaran</b>.</li>
            <li>Data Anda <b>tidak akan dijual atau disalahgunakan</b> kepada pihak ketiga.</li>
            <li>Foto identitas hanya dapat diakses oleh Admin/Petugas berwenang di sistem internal APORTIL.</li>
        </ul>

        <h2>5. Aturan Boarding (Naik Kapal)</h2>
        <ul>
            <li>Penumpang wajib tiba di pelabuhan minimal 30 menit sebelum jadwal keberangkatan.</li>
            <li>Tunjukkan E-Ticket (QR Code) kepada petugas untuk dipindai (Scan).</li>
            <li>Penumpang yang telat datang dan melewatkan kapal tidak berhak menuntut ganti rugi.</li>
        </ul>

        <div style="text-align: center;">
            <a href="pesan.php" class="btn-back">Saya Mengerti & Setuju</a>
        </div>
    </div>

</body>
</html>
