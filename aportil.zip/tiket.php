<?php
require_once 'config.php';

$kode = $_GET['kode'] ?? '';

if (isset($_GET['batal']) && $_GET['batal'] == '1') {
    $stmt_cek = $mysqli->prepare("SELECT id, status FROM booking WHERE kode_booking = ?");
    $stmt_cek->bind_param('s', $kode);
    $stmt_cek->execute();
    $b = $stmt_cek->get_result()->fetch_assoc();
    $stmt_cek->close();

    if ($b && ($b['status'] == 'Paid' || $b['status'] == 'Pending')) {
        $stmt_batal = $mysqli->prepare("UPDATE booking SET status = 'Cancelled' WHERE id = ?");
        $stmt_batal->bind_param('i', $b['id']);
        $stmt_batal->execute();
        $stmt_batal->close();
        catatLog("Batal Mandiri", "Tiket $kode dibatalkan oleh penumpang.");
        header("Location: tiket.php?kode=" . urlencode($kode) . "&status=cancelled");
        exit;
    }
}

$sql = "SELECT b.*, v.kode_voyage, v.tanggal, v.jam_berangkat, k.nama_kapal, p1.nama as asal, p2.nama as tujuan 
        FROM booking b
        JOIN voyage v ON b.voyage_id = v.id
        JOIN kapal k ON v.kapal_id = k.id
        JOIN pelabuhan p1 ON v.pelabuhan_asal_id = p1.id
        JOIN pelabuhan p2 ON v.pelabuhan_tujuan_id = p2.id
        WHERE b.kode_booking = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param('s', $kode);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    die("<h2 style='text-align:center; margin-top:50px;'>Tiket Tidak Ditemukan.</h2>");
}

$sql2 = "SELECT * FROM tiket WHERE booking_id = ?";
$stmt2 = $mysqli->prepare($sql2);
$stmt2->bind_param('i', $booking['id']);
$stmt2->execute();
$penumpangs = $stmt2->get_result();
$stmt2->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Ticket - <?= $kode ?></title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Poppins:wght@400;600;700&display=swap');
        body { font-family: 'Poppins', sans-serif; background: #e2e8f0; padding: 20px; display: flex; flex-direction: column; align-items: center; margin: 0; }
        .ticket-container { background: #fff; width: 100%; max-width: 450px; border-radius: 20px; box-shadow: 0 15px 35px rgba(0,0,0,0.15); overflow: hidden; position: relative; }
        .ticket-cancelled { opacity: 0.6; filter: grayscale(100%); }
        .stamp-cancelled { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-30deg); font-size: 50px; font-weight: 900; color: rgba(211, 47, 47, 0.5); border: 5px solid rgba(211, 47, 47, 0.5); padding: 10px 20px; border-radius: 10px; z-index: 10; letter-spacing: 5px; pointer-events: none; }
        .ticket-header { background: #0B2E6F; color: white; padding: 25px 20px; text-align: center; position: relative; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .ticket-header h1 { margin: 0; font-size: 24px; letter-spacing: 2px; }
        .ticket-header p { margin: 5px 0 0; font-size: 12px; opacity: 0.8; letter-spacing: 1px; }
        .lang-selector { position: absolute; top: 10px; right: 10px; z-index: 10; }
        .lang-selector select { padding: 4px; border-radius: 5px; font-size: 11px; border: none; cursor: pointer; }
        .ticket-body { padding: 30px 25px; }
        .qr-section { text-align: center; margin-bottom: 25px; }
        .qr-section img { width: 160px; height: 160px; border: 2px solid #eee; border-radius: 10px; padding: 5px; }
        .kode-booking { font-family: 'Share Tech Mono', monospace; font-size: 24px; font-weight: bold; color: #0B2E6F; letter-spacing: 3px; margin-top: 10px; background: #f1f5f9; display: inline-block; padding: 5px 15px; border-radius: 8px; }
        .route-info { display: flex; justify-content: space-between; align-items: center; background: #f8fafc; border-radius: 12px; padding: 15px; margin-bottom: 20px; border: 1px solid #e2e8f0; }
        .route-text { text-align: center; flex: 1; }
        .route-text h3 { margin: 0; font-size: 18px; color: #1e293b; }
        .route-text span { font-size: 11px; color: #64748b; text-transform: uppercase; letter-spacing: 1px; }
        .route-arrow { font-size: 24px; color: #0B2E6F; margin: 0 15px; }
        .details-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px; }
        .detail-item label { display: block; font-size: 11px; color: #64748b; text-transform: uppercase; margin-bottom: 3px; }
        .detail-item span { display: block; font-size: 14px; font-weight: 600; color: #1e293b; }
        .pax-list { background: #fff; border: 1px dashed #cbd5e1; border-radius: 12px; padding: 15px; margin-bottom: 20px; }
        .pax-list h4 { margin: 0 0 10px 0; font-size: 13px; color: #0B2E6F; border-bottom: 1px solid #eee; padding-bottom: 5px; }
        .pax-list ul { margin: 0; padding-left: 20px; font-size: 13px; color: #334155; }
        .pax-list li { margin-bottom: 5px; }
        .ticket-footer { border-top: 2px dashed #e2e8f0; padding-top: 15px; display: flex; justify-content: space-between; align-items: center; }
        .total-label { font-size: 12px; color: #64748b; text-transform: uppercase; }
        .total-price { font-size: 22px; font-weight: 700; color: #0B2E6F; }
        .action-buttons { display: flex; gap: 10px; width: 100%; max-width: 450px; margin-top: 20px; flex-wrap: wrap; }
        .btn-action { flex: 1; min-width: 120px; padding: 15px; border: none; border-radius: 12px; font-size: 15px; font-weight: bold; cursor: pointer; text-align: center; transition: 0.2s; text-decoration: none; display: flex; justify-content: center; align-items: center; gap: 5px; }
        .btn-pdf { background: #d32f2f; color: white; }
        .btn-print { background: #0B2E6F; color: white; }
        .btn-cancel { background: #ff9800; color: white; }
        .btn-edit { background: #9c27b0; color: white; }
        @media print {
            body { background: #fff; padding: 0; }
            .ticket-container { box-shadow: none; border: 2px solid #0B2E6F; margin: 0 auto; }
            .action-buttons, .lang-selector { display: none; }
            .ticket-header { background: #0B2E6F !important; color: white !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .ticket-cancelled { filter: none; opacity: 1; }
        }
    </style>
</head>
<body>

    <?php if (isset($_GET['status']) && $_GET['status'] == 'cancelled'): ?>
        <div class="alert-error" style="max-width: 450px; width: 100%; text-align: center; background: #ffebee; padding: 15px; border-radius: 8px; color: #d32f2f; font-weight: bold; margin-bottom: 20px; border-left: 5px solid #d32f2f;">
            ⚠️ Tiket berhasil dibatalkan. Kursi Anda telah dikembalikan ke sistem.
        </div>
    <?php endif; ?>

    <div id="ticket-to-pdf" class="<?= $booking['status'] == 'Cancelled' ? 'ticket-cancelled' : '' ?>" style="position: relative;">
        <?php if ($booking['status'] == 'Cancelled'): ?>
            <div class="stamp-cancelled">CANCELLED</div>
        <?php endif; ?>

        <div class="ticket-container" style="margin: 0 auto; box-shadow: none; border: 1px solid #eee;">
            <div class="lang-selector">
                <form method="GET">
                    <input type="hidden" name="kode" value="<?= $kode ?>">
                    <select name="lang" onchange="this.form.submit()">
                        <option value="tet" <?= $_SESSION['lang'] == 'tet' ? 'selected' : '' ?>>TET</option>
                        <option value="id" <?= $_SESSION['lang'] == 'id' ? 'selected' : '' ?>>ID</option>
                        <option value="en" <?= $_SESSION['lang'] == 'en' ? 'selected' : '' ?>>EN</option>
                    </select>
                </form>
            </div>
            <div class="ticket-header">
                <h1>⚓ APORTIL, I.P.</h1>
                <p>ADMINISTRASAUN PORTU TIMOR-LESTE</p>
            </div>
            
            <div class="ticket-body">
                <div class="qr-section">
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=<?= $kode ?>" alt="QR Code" crossorigin="anonymous">
                    <div class="kode-booking"><?= $kode ?></div>
                </div>
                
                <div class="route-info">
                    <div class="route-text">
                        <span><?= __('origin') ?></span>
                        <h3><?= htmlspecialchars($booking['asal']) ?></h3>
                    </div>
                    <div class="route-arrow">➔</div>
                    <div class="route-text">
                        <span><?= __('destination') ?></span>
                        <h3><?= htmlspecialchars($booking['tujuan']) ?></h3>
                    </div>
                </div>
                
                <div class="details-grid">
                    <div class="detail-item">
                        <label><?= __('vessel') ?></label>
                        <span><?= htmlspecialchars($booking['nama_kapal']) ?></span>
                    </div>
                    <div class="detail-item">
                        <label><?= __('voyage') ?></label>
                        <span><?= $booking['kode_voyage'] ?></span>
                    </div>
                    <div class="detail-item">
                        <label><?= __('date') ?></label>
                        <span><?= date('d M Y', strtotime($booking['tanggal'])) ?></span>
                    </div>
                    <div class="detail-item">
                        <label><?= __('departure_time') ?></label>
                        <span><?= date('H:i', strtotime($booking['jam_berangkat'])) ?> WITA</span>
                    </div>
                </div>
                
                <div class="pax-list">
                    <h4><?= __('passenger_data') ?>:</h4>
                    <ul>
                        <?php 
                        $pax_data = [];
                        while($p = $penumpangs->fetch_assoc()) { $pax_data[] = $p; }
                        foreach($pax_data as $p): 
                        ?>
                            <li>
                                <?= htmlspecialchars($p['nama_penumpang']) ?> 
                                <span style="font-size:10px; color:#64748b;">
                                    (<?= htmlspecialchars($p['no_identitas']) ?>) - <?= $p['kelas'] ?>
                                    <?= !empty($p['negara']) ? ' | 🌍 '.$p['negara'] : '' ?>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                
                <div class="ticket-footer">
                    <div>
                        <div class="total-label"><?= __('total_pay') ?></div>
                        <div class="total-price">$<?= number_format($booking['total_bayar'], 2) ?> <span style="font-size:12px;">USD</span></div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-size: 10px; color: #64748b; max-width: 150px;"><?= __('show_qr') ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- TOMBOL AKSI -->
    <div class="action-buttons">
        <?php if ($booking['status'] == 'Pending'): ?>
            <a href="edit_penumpang.php?kode=<?= $kode ?>" class="btn-action btn-edit">✏️ Edit Data Penumpang</a>
            <a href="upload_bukti.php?kode=<?= $kode ?>" class="btn-action btn-cancel" style="background: #ff5722;">📤 Upload Bukti TF</a>
            <a href="?kode=<?= $kode ?>&batal=1" class="btn-action btn-cancel" onclick="return confirm('Yakin batalkan tiket ini?')">❌ Batalkan</a>

        <?php elseif ($booking['status'] == 'Paid'): ?>
            <button onclick="downloadPDF()" class="btn-action btn-pdf">⬇️ Download PDF</button>
            <button onclick="window.print()" class="btn-action btn-print">🖨️ Print</button>
            <a href="?kode=<?= $kode ?>&batal=1" class="btn-action btn-cancel" onclick="return confirm('Yakin batalkan tiket ini? Dana akan diproses refund.')">❌ Batalkan Tiket</a>

        <?php else: ?>
            <button onclick="window.print()" class="btn-action btn-print" style="width: 100%;">🖨️ Cetak Bukti Batal</button>
        <?php endif; ?>
    </div>

    <script>
        function downloadPDF() {
            const element = document.getElementById('ticket-to-pdf');
            const opt = {
                margin:       5,
                filename:     'E-Ticket-<?= $kode ?>.pdf',
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2, useCORS: true },
                jsPDF:        { unit: 'mm', format: 'a5', orientation: 'portrait' }
            };
            alert('Sedang membuat file PDF, mohon tunggu sebentar...');
            html2pdf().set(opt).from(element).save();
        }
    </script>
</body>
</html>
