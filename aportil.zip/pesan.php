<?php
require_once 'config.php';
require_once 'negara.php'; 

$step = 1;
$kode_booking = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buat_pesanan'])) {
    $voyage_id = (int)$_POST['voyage_id'];
    $nama_pemesan = trim($_POST['nama_pemesan']);
    $no_hp = trim($_POST['no_hp']);
    $kelas = $_POST['kelas'];
    $jenis_kendaraan = $_POST['jenis_kendaraan'];
    $plat_nomor = trim($_POST['plat_nomor']);
    $jumlah_kargo = (int)$_POST['jumlah_kargo'];
    $deskripsi_kargo = trim($_POST['deskripsi_kargo'] ?? '');
    
    $voucher_id = (int)($_POST['voucher_id'] ?? 0);
    $diskon = (float)($_POST['diskon_val'] ?? 0);
    
    $nama_penumpangs = $_POST['nama_penumpang'] ?? [];
    $no_identitas_arr = $_POST['no_identitas'] ?? [];
    $negara_arr = $_POST['negara'] ?? [];
    $jumlah_pax = count($nama_penumpangs);

    $uploaded_photos = [];
    if (isset($_FILES['foto_identitas'])) {
        for ($i = 0; $i < $jumlah_pax; $i++) {
            $uploaded_photos[$i] = null;
            if (isset($_FILES['foto_identitas']['name'][$i]) && $_FILES['foto_identitas']['error'][$i] === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['foto_identitas']['name'][$i], PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg', 'jpeg', 'png']) && $_FILES['foto_identitas']['size'][$i] <= 3 * 1024 * 1024) {
                    $new_name = 'id_' . uniqid() . '_' . $i . '.' . $ext;
                    if (move_uploaded_file($_FILES['foto_identitas']['tmp_name'][$i], 'uploads/' . $new_name)) {
                        $uploaded_photos[$i] = $new_name;
                    }
                }
            }
        }
    }

    $sql = "SELECT v.*, k.kapasitas_ekonomi, k.kapasitas_bisnis, t.harga_ekonomi, t.harga_bisnis, t.harga_motor, t.harga_mobil, t.harga_kargo,
            (SELECT COUNT(tk.id) FROM tiket tk JOIN booking bk ON tk.booking_id = bk.id WHERE bk.voyage_id = v.id AND bk.status != 'Cancelled' AND tk.kelas = 'Ekonomi') as terjual_eko,
            (SELECT COUNT(tk.id) FROM tiket tk JOIN booking bk ON tk.booking_id = bk.id WHERE bk.voyage_id = v.id AND bk.status != 'Cancelled' AND tk.kelas = 'Bisnis') as terjual_bis
            FROM voyage v 
            JOIN kapal k ON v.kapal_id = k.id
            JOIN tarif t ON v.pelabuhan_asal_id = t.pelabuhan_asal_id AND v.pelabuhan_tujuan_id = t.pelabuhan_tujuan_id
            WHERE v.id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('i', $voyage_id);
    $stmt->execute();
    $v = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($v && $jumlah_pax > 0) {
        $sisa_eko = $v['kapasitas_ekonomi'] - $v['terjual_eko'];
        $sisa_bis = $v['kapasitas_bisnis'] - $v['terjual_bis'];
        
        $valid = true;
        if ($kelas == 'Ekonomi' && $jumlah_pax > $sisa_eko) {
            $valid = false;
            $error_msg = "Kursi Ekonomi tidak cukup. Sisa: $sisa_eko";
        } elseif ($kelas == 'Bisnis' && $jumlah_pax > $sisa_bis) {
            $valid = false;
            $error_msg = "Kursi Bisnis tidak cukup. Sisa: $sisa_bis";
        }

        if ($valid) {
            $total_awal = 0;
            $harga_tiket = ($kelas == 'Bisnis') ? $v['harga_bisnis'] : $v['harga_ekonomi'];
            $total_awal += ($harga_tiket * $jumlah_pax);
            if ($jenis_kendaraan == 'Motor') $total_awal += $v['harga_motor'];
            if ($jenis_kendaraan == 'Mobil') $total_awal += $v['harga_mobil'];
            $total_awal += ($v['harga_kargo'] * $jumlah_kargo);

            $final_diskon = 0;
            $final_voucher_id = NULL;
            if ($voucher_id > 0 && $diskon > 0) {
                $chk = $mysqli->prepare("SELECT * FROM voucher WHERE id = ? AND status = 'aktif'");
                $chk->bind_param('i', $voucher_id);
                $chk->execute();
                $vch = $chk->get_result()->fetch_assoc();
                $chk->close();
                
                if ($vch) {
                    if ($vch['kuota'] == 0 || $vch['terpakai'] < $vch['kuota']) {
                        $final_voucher_id = $voucher_id;
                        $final_diskon = $diskon;
                        $mysqli->query("UPDATE voucher SET terpakai = terpakai + 1 WHERE id = $voucher_id");
                    }
                }
            }

            $total_akhir = $total_awal - $final_diskon;
            if ($total_akhir < 0) $total_akhir = 0;

            $kode = 'APT-' . date('ymd') . '-' . strtoupper(substr(uniqid(), -4));

            $stmt = $mysqli->prepare("INSERT INTO booking (kode_booking, voyage_id, nama_pemesan, no_hp, total_bayar, voucher_id, diskon, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')");
            $stmt->bind_param('sissdii', $kode, $voyage_id, $nama_pemesan, $no_hp, $total_akhir, $final_voucher_id, $final_diskon);
            $stmt->execute();
            $booking_id = $mysqli->insert_id;
            $stmt->close();

            for ($i = 0; $i < $jumlah_pax; $i++) {
                $nm = trim($nama_penumpangs[$i]);
                $id_num = trim($no_identitas_arr[$i]);
                $negara = trim($negara_arr[$i] ?? 'Timor-Leste');
                $foto = $uploaded_photos[$i];
                if (empty($foto)) $foto = NULL;
                
                $stmt2 = $mysqli->prepare("INSERT INTO tiket (booking_id, nama_penumpang, no_identitas, negara, foto_identitas, kelas, jenis_kendaraan, plat_nomor, jumlah_kargo, deskripsi_kargo, harga_tiket) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt2->bind_param('isssssssisd', $booking_id, $nm, $id_num, $negara, $foto, $kelas, $jenis_kendaraan, $plat_nomor, $jumlah_kargo, $deskripsi_kargo, $harga_tiket);
                $stmt2->execute();
                $stmt2->close();
            }

            $kode_booking = $kode;
            $step = 3; 
        } else {
            $step = 2;
            $_GET['cari'] = 1;
            $_GET['asal'] = $v['pelabuhan_asal_id'];
            $_GET['tujuan'] = $v['pelabuhan_tujuan_id'];
            $_GET['tanggal'] = $v['tanggal'];
        }
    }
} elseif (isset($_GET['cari'])) {
    $step = 2;
}

$pelabuhan = $mysqli->query("SELECT * FROM pelabuhan");
$map_data = [];
$res_map = $mysqli->query("SELECT nama, latitude, longitude FROM pelabuhan");
while($m = $res_map->fetch_assoc()) { $map_data[] = $m; }

// Dapatkan ID Pelabuhan Dili untuk rute
$id_dili = 1;
?>
<!DOCTYPE html>
<html lang="<?= $_SESSION['lang'] ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= __('title_app') ?></title>
    <link rel="stylesheet" href="style.css">
    <!-- LEAFLET MAP CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <!-- LEAFLET LOCATE CONTROL CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet.locatecontrol@0.79.0/dist/L.Control.Locate.min.css" />
    <script>
        if (localStorage.getItem('theme') === 'dark') {
            document.documentElement.classList.add('dark-mode');
            document.addEventListener('DOMContentLoaded', () => document.body.classList.add('dark-mode'));
        }
    </script>
    <style>
        .floating-wa { position: fixed; bottom: 25px; right: 25px; background-color: #25D366; color: white; border-radius: 50px; text-align: center; box-shadow: 2px 4px 10px rgba(0,0,0,0.3); z-index: 1000; width: 60px; height: 60px; display: flex; justify-content: center; align-items: center; text-decoration: none; transition: all 0.3s ease; }
        .floating-wa:hover { background-color: #128C7E; transform: scale(1.1) translateY(-5px); }
        .floating-wa svg { width: 35px; height: 35px; fill: white; }
        .leaflet-control-locate a { cursor: pointer; }
    </style>
</head>
<body style="background: var(--bg); display: flex; flex-direction: column; min-height: 100vh;">

    <nav class="navbar" style="background: var(--primary); display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; padding: 10px 15px; gap: 10px;">
        <div class="logo" style="font-weight: bold; color: white; flex: 1; min-width: 150px;">⚓ <?= htmlspecialchars($SETTINGS['nama_perusahaan'] ?? 'APORTIL Ferry') ?></div>
        
        <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: flex-end;">
            <button class="theme-toggle" onclick="toggleTheme()" id="theme-btn" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 6px 10px; border-radius: 5px; cursor: pointer; font-size: 14px;">🌙</button>
            <a href="cek_tiket.php" style="background: #ff9800; color: white; padding: 6px 10px; border-radius: 5px; text-decoration: none; font-size: 12px; font-weight: bold; white-space: nowrap;">🎫 Cek Tiket</a>
            
            <form method="GET" style="margin: 0; display: flex;">
                <?php if(isset($_GET['cari'])): ?>
                    <input type="hidden" name="cari" value="1">
                    <input type="hidden" name="asal" value="<?= $_GET['asal'] ?? '' ?>">
                    <input type="hidden" name="tujuan" value="<?= $_GET['tujuan'] ?? '' ?>">
                    <input type="hidden" name="tanggal" value="<?= $_GET['tanggal'] ?? '' ?>">
                <?php endif; ?>
                <select name="lang" onchange="this.form.submit()" style="padding: 6px 10px; border-radius: 5px; font-size: 12px; background: #fff; color: #333; border: 1px solid #ccc; font-weight: bold; cursor: pointer;">
                    <option value="tet" <?= $_SESSION['lang'] == 'tet' ? 'selected' : '' ?>>🇹🇱 Tetum</option>
                    <option value="id" <?= $_SESSION['lang'] == 'id' ? 'selected' : '' ?>>🇮🇩 Indonesia</option>
                    <option value="en" <?= $_SESSION['lang'] == 'en' ? 'selected' : '' ?>>🇬🇧 English</option>
                </select>
            </form>
            <a href="login.php" style="color: white; text-decoration: none; font-size: 12px; background: rgba(255,255,255,0.1); padding: 6px 10px; border-radius: 5px; white-space: nowrap;"><?= __('admin_login') ?></a>
        </div>
    </nav>

    <div style="max-width: 800px; margin: 0 auto; padding: 20px; flex: 1; width: 100%;">
        
        <?php if ($error_msg): ?>
            <div class="alert-error" style="font-size: 16px;"><?= $error_msg ?></div>
        <?php endif; ?>

        <?php if ($step == 1): ?>
            <div class="card">
                <h2 style="color: var(--primary); text-align: center; margin-bottom: 5px;"><?= __('book_ticket') ?></h2>
                <p style="text-align: center; color: var(--text); opacity: 0.7; margin-bottom: 20px;"><?= __('route') ?>: Dili - Atauro - Oecusse</p>

                <div id="map"></div>

                <form method="GET" style="margin-top: 20px;">
                    <input type="hidden" name="cari" value="1">
                    <input type="hidden" name="lang" value="<?= $_SESSION['lang'] ?>">
                    <div class="form-row">
                        <div class="form-group">
                            <label><?= __('origin') ?></label>
                            <select name="asal" required>
                                <option value="">-- <?= __('origin') ?> --</option>
                                <?php $pelabuhan->data_seek(0); while($p = $pelabuhan->fetch_assoc()): ?>
                                    <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nama']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><?= __('destination') ?></label>
                            <select name="tujuan" required>
                                <option value="">-- <?= __('destination') ?> --</option>
                                <?php $pelabuhan->data_seek(0); while($p = $pelabuhan->fetch_assoc()): ?>
                                    <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nama']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><?= __('date') ?></label>
                            <input type="date" name="tanggal" required value="<?= date('Y-m-d') ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn-primary" style="padding: 12px;">🔍 <?= __('search_schedule') ?></button>
                </form>
            </div>

        <?php elseif ($step == 2): ?>
            <?php
            $asal_id = (int)$_GET['asal'];
            $tujuan_id = (int)$_GET['tujuan'];
            $tanggal = $_GET['tanggal'];
            
            $sql = "SELECT v.*, k.nama_kapal, k.kapasitas_ekonomi, k.kapasitas_bisnis, p1.nama as asal_nama, p2.nama as tujuan_nama,
                    t.harga_ekonomi, t.harga_bisnis, t.harga_kargo, t.harga_motor, t.harga_mobil,
                    (SELECT COUNT(tk.id) FROM tiket tk JOIN booking bk ON tk.booking_id = bk.id WHERE bk.voyage_id = v.id AND bk.status != 'Cancelled' AND tk.kelas = 'Ekonomi') as terjual_eko,
                    (SELECT COUNT(tk.id) FROM tiket tk JOIN booking bk ON tk.booking_id = bk.id WHERE bk.voyage_id = v.id AND bk.status != 'Cancelled' AND tk.kelas = 'Bisnis') as terjual_bis
                    FROM voyage v 
                    JOIN kapal k ON v.kapal_id = k.id 
                    JOIN pelabuhan p1 ON v.pelabuhan_asal_id = p1.id 
                    JOIN pelabuhan p2 ON v.pelabuhan_tujuan_id = p2.id 
                    JOIN tarif t ON v.pelabuhan_asal_id = t.pelabuhan_asal_id AND v.pelabuhan_tujuan_id = t.pelabuhan_tujuan_id
                    WHERE v.pelabuhan_asal_id = ? AND v.pelabuhan_tujuan_id = ? AND v.tanggal = ?
                    ORDER BY v.jam_berangkat ASC";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param('iis', $asal_id, $tujuan_id, $tanggal);
            $stmt->execute();
            $result = $stmt->get_result();
            ?>

            <div class="card" style="margin-bottom: 20px;">
                <a href="pesan.php?lang=<?= $_SESSION['lang'] ?>" style="text-decoration: none; color: var(--primary); font-weight: bold;">← <?= __('back_to_search') ?></a>
                <h3 style="margin-top: 10px;"><?= __('available_schedule') ?> (<?= date('d M Y', strtotime($tanggal)) ?>)</h3>
            </div>

            <?php if ($result->num_rows == 0): ?>
                <div class="alert-error"><?= __('no_schedule') ?></div>
            <?php else: ?>
                <?php while($v = $result->fetch_assoc()): 
                    $sisa_eko = $v['kapasitas_ekonomi'] - $v['terjual_eko'];
                    $sisa_bis = $v['kapasitas_bisnis'] - $v['terjual_bis'];
                    $is_full = ($sisa_eko <= 0 && $sisa_bis <= 0);
                ?>
                <div class="card" style="<?= $is_full ? 'opacity: 0.6;' : '' ?>">
                    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 10px;">
                        <div>
                            <h3 style="color: var(--primary); margin: 0;"><?= htmlspecialchars($v['nama_kapal']) ?></h3>
                            <span style="font-size: 12px; color: var(--text); opacity: 0.7;"><?= __('voyage') ?>: <?= htmlspecialchars($v['kode_voyage']) ?></span>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-size: 18px; font-weight: bold; color: var(--primary);">⏰ <?= date('H:i', strtotime($v['jam_berangkat'])) ?></div>
                            <span style="font-size: 12px; color: var(--text); opacity: 0.7;"><?= __('remaining_seats') ?>: Eko (<?= max(0, $sisa_eko) ?>) | Bis (<?= max(0, $sisa_bis) ?>)</span>
                        </div>
                    </div>

                    <?php if($is_full): ?>
                        <div class="alert-error" style="text-align:center; font-weight:bold; margin-bottom:0;">❌ <?= __('sold_out') ?></div>
                    <?php else: ?>
                    <form method="POST" enctype="multipart/form-data" id="formPesan">
                        <input type="hidden" name="voyage_id" value="<?= $v['id'] ?>">
                        <input type="hidden" name="voucher_id" id="hidden_voucher_id" value="0">
                        <input type="hidden" name="diskon_val" id="hidden_diskon" value="0">
                        
                        <h4 style="margin-bottom: 10px; color: var(--text);"><?= __('booker_name') ?></h4>
                        <div class="form-row">
                            <div class="form-group">
                                <label><?= __('booker_name') ?></label>
                                <input type="text" name="nama_pemesan" required>
                            </div>
                            <div class="form-group">
                                <label><?= __('whatsapp') ?></label>
                                <input type="text" name="no_hp" required placeholder="+670...">
                            </div>
                        </div>

                        <h4 style="margin: 15px 0 10px 0; color: var(--text);"><?= __('class') ?> & <?= __('num_passengers') ?></h4>
                        <div class="form-row">
                            <div class="form-group">
                                <label><?= __('class') ?></label>
                                <select name="kelas" required onchange="updateHarga()" id="kelasSelect">
                                    <?php if($sisa_eko > 0): ?>
                                        <option value="Ekonomi" data-harga="<?= $v['harga_ekonomi'] ?>">Ekonomi ($<?= number_format($v['harga_ekonomi'], 2) ?>) - <?= __('remaining_seats') ?> <?= $sisa_eko ?></option>
                                    <?php endif; ?>
                                    <?php if($sisa_bis > 0): ?>
                                        <option value="Bisnis" data-harga="<?= $v['harga_bisnis'] ?>">Bisnis ($<?= number_format($v['harga_bisnis'], 2) ?>) - <?= __('remaining_seats') ?> <?= $sisa_bis ?></option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label><?= __('num_passengers') ?></label>
                                <input type="number" name="jumlah_pax" id="jumlah_pax" value="1" min="1" max="<?= max($sisa_eko, $sisa_bis) ?>" onchange="generateForms()" required>
                            </div>
                        </div>

                        <div id="passenger-inputs" style="background: var(--bg); padding: 15px; border-radius: 8px; margin-bottom: 15px; border: 1px solid var(--border);"></div>

                        <h4 style="margin: 15px 0 10px 0; color: var(--text);"><?= __('optional_add') ?></h4>
                        <div class="form-row">
                            <div class="form-group">
                                <label><?= __('vehicle') ?></label>
                                <select name="jenis_kendaraan" id="kendaraanSelect" onchange="updateHarga()">
                                    <option value="Tidak Ada" data-harga="0"><?= __('none') ?></option>
                                    <option value="Motor" data-harga="<?= $v['harga_motor'] ?>">Motor (+$<?= number_format($v['harga_motor'], 2) ?>)</option>
                                    <option value="Mobil" data-harga="<?= $v['harga_mobil'] ?>">Mobil (+$<?= number_format($v['harga_mobil'], 2) ?>)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label><?= __('plate_number') ?></label>
                                <input type="text" name="plat_nomor" placeholder="12-345 AB">
                            </div>
                            <div class="form-group">
                                <label><?= __('cargo') ?></label>
                                <input type="number" name="jumlah_kargo" id="kargoInput" value="0" min="0" onchange="updateHarga()">
                            </div>
                            <div class="form-group">
                                <label><?= __('cargo_desc') ?></label>
                                <input type="text" name="deskripsi_kargo" placeholder="Kuda, Lemari...">
                            </div>
                        </div>

                        <div style="background: #fff3e0; padding: 15px; border-radius: 8px; margin-bottom: 15px; border: 1px dashed #ff9800;">
                            <label style="font-weight: bold; color: #e65100; display: block; margin-bottom: 5px;">🎟️ Punya Kode Promo?</label>
                            <div style="display: flex; gap: 10px;">
                                <input type="text" id="input_voucher" placeholder="Masukkan Kode Promo" style="flex: 1; text-transform: uppercase; padding: 10px;">
                                <button type="button" onclick="applyVoucher()" style="background: #ff9800; color: white; border: none; padding: 10px 20px; border-radius: 6px; font-weight: bold; cursor: pointer;">Terapkan</button>
                            </div>
                            <small id="msg_voucher" style="display:block; margin-top: 5px; font-weight: bold;"></small>
                        </div>

                        <div class="alert-success" style="margin-top: 15px; font-size: 18px; font-weight: bold; text-align: center;">
                            <?= __('total_pay') ?>: <span id="total_harga">$<?= number_format($v['harga_ekonomi'], 2) ?></span> USD
                            <div id="diskon_info" style="font-size: 14px; color: #d32f2f; display: none;"></div>
                        </div>

                        <button type="submit" name="buat_pesanan" class="btn-primary" style="margin-top: 15px;"><?= __('make_order') ?> ➔</button>
                    </form>
                    <script>
                        const hargaKargo = <?= $v['harga_kargo'] ?>;
                        const daftarNegara = <?= json_encode($daftar_negara) ?>;
                        let currentDiskon = 0;

                        function generateForms() {
                            let count = parseInt(document.getElementById('jumlah_pax').value) || 1;
                            let container = document.getElementById('passenger-inputs');
                            container.innerHTML = '';
                            
                            let negaraOptions = '';
                            daftarNegara.forEach(function(n) {
                                negaraOptions += `<option value="${n}" ${n === 'Timor-Leste' ? 'selected' : ''}>${n}</option>`;
                            });
                            
                            for(let i=1; i<=count; i++) {
                                container.innerHTML += `
                                    <div style="background: var(--white); padding: 15px; border-radius: 8px; margin-bottom: 10px; border-left: 4px solid #0B2E6F;">
                                        <h5 style="color: var(--text); margin-bottom: 10px; font-size: 14px;">👤 Penumpang ${i}</h5>
                                        <div class="form-row" style="margin-bottom: 10px;">
                                            <div class="form-group">
                                                <label style="color: var(--text) !important; font-weight: bold;"><?= __('passenger_name') ?> ${i}</label>
                                                <input type="text" name="nama_penumpang[]" style="color: var(--text) !important; background: var(--input-bg) !important; border: 1px solid var(--border);" required>
                                            </div>
                                            <div class="form-group">
                                                <label style="color: var(--text) !important; font-weight: bold;"><?= __('identity_id') ?> ${i}</label>
                                                <input type="text" name="no_identitas[]" style="color: var(--text) !important; background: var(--input-bg) !important; border: 1px solid var(--border);" required placeholder="BUK / Passport / KTP">
                                            </div>
                                        </div>
                                        <div class="form-row" style="margin-bottom: 0;">
                                            <div class="form-group">
                                                <label style="color: var(--text) !important; font-weight: bold;">🌍 Negara / Country</label>
                                                <select name="negara[]" style="color: var(--text) !important; background: var(--input-bg) !important; border: 1px solid var(--border);">
                                                    ${negaraOptions}
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label style="color: var(--text) !important; font-weight: bold;">📷 Foto KTP/Passport (Maks 3MB)</label>
                                                <input type="file" name="foto_identitas[]" accept="image/jpeg, image/png" style="color: var(--text) !important; background: var(--input-bg) !important; border: 1px solid var(--border); padding: 8px;">
                                            </div>
                                        </div>
                                    </div>
                                `;
                            }
                            updateHarga();
                        }

                        function updateHarga() {
                            let hargaTiket = parseFloat(document.getElementById('kelasSelect').selectedOptions[0].dataset.harga);
                            let jumlahPax = parseInt(document.getElementById('jumlah_pax').value) || 1;
                            let hargaKendaraan = parseFloat(document.getElementById('kendaraanSelect').selectedOptions[0].dataset.harga) || 0;
                            let jumlahKargo = parseInt(document.getElementById('kargoInput').value) || 0;
                            
                            let total_awal = (hargaTiket * jumlahPax) + hargaKendaraan + (jumlahKargo * hargaKargo);
                            let total_akhir = total_awal - currentDiskon;
                            
                            if(total_akhir < 0) total_akhir = 0;
                            
                            document.getElementById('total_harga').innerText = '$' + total_akhir.toFixed(2);
                            
                            if(currentDiskon > 0) {
                                document.getElementById('diskon_info').style.display = 'block';
                                document.getElementById('diskon_info').innerText = 'Potongan Voucher: -$' + currentDiskon.toFixed(2);
                            } else {
                                document.getElementById('diskon_info').style.display = 'none';
                            }
                        }

                        function applyVoucher() {
                            let kode = document.getElementById('input_voucher').value;
                            if(!kode) return alert('Masukkan kode voucher!');
                            
                            let hargaTiket = parseFloat(document.getElementById('kelasSelect').selectedOptions[0].dataset.harga);
                            let jumlahPax = parseInt(document.getElementById('jumlah_pax').value) || 1;
                            let hargaKendaraan = parseFloat(document.getElementById('kendaraanSelect').selectedOptions[0].dataset.harga) || 0;
                            let jumlahKargo = parseInt(document.getElementById('kargoInput').value) || 0;
                            let total_awal = (hargaTiket * jumlahPax) + hargaKendaraan + (jumlahKargo * hargaKargo);

                            let formData = new FormData();
                            formData.append('kode', kode);
                            formData.append('total_awal', total_awal);

                            fetch('cek_voucher.php', { method: 'POST', body: formData })
                            .then(res => res.json())
                            .then(data => {
                                let msg = document.getElementById('msg_voucher');
                                msg.style.display = 'block';
                                if(data.ok) {
                                    msg.style.color = 'green';
                                    msg.innerText = data.msg;
                                    currentDiskon = parseFloat(data.diskon);
                                    document.getElementById('hidden_voucher_id').value = data.voucher_id;
                                    document.getElementById('hidden_diskon').value = currentDiskon;
                                } else {
                                    msg.style.color = 'red';
                                    msg.innerText = data.msg;
                                    currentDiskon = 0;
                                    document.getElementById('hidden_voucher_id').value = 0;
                                    document.getElementById('hidden_diskon').value = 0;
                                }
                                updateHarga();
                            });
                        }

                        generateForms();
                    </script>
                    <?php endif; ?>
                </div>
                <?php endwhile; ?>
            <?php endif; ?>

        <?php elseif ($step == 3): ?>
            <div class="card" style="text-align: center; padding: 40px 20px;">
                <h2 style="color: #2e7d32;">✅ <?= __('order_success') ?></h2>
                <p style="margin: 15px 0; font-size: 16px;"><?= __('booking_code') ?>:</p>
                <div style="font-size: 28px; font-weight: bold; color: var(--primary); letter-spacing: 2px; margin-bottom: 20px;">
                    <?= $kode_booking ?>
                </div>
                
                <div class="alert-success" style="text-align: left;">
                    <p><b><?= __('payment_instruction') ?>:</b></p>
                    
                    <?php if(!empty($SETTINGS['qris_image'])): ?>
                        <div style="text-align: center; margin: 15px 0;">
                            <p style="margin-bottom: 10px; font-weight: bold;">Scan QRIS untuk Membayar:</p>
                            <img src="uploads/<?= htmlspecialchars($SETTINGS['qris_image']) ?>" style="max-width: 200px; border-radius: 8px; border: 2px solid var(--border);">
                        </div>
                        <p style="text-align: center; margin-bottom: 10px;">Atau transfer ke rekening:</p>
                    <?php else: ?>
                        <p><?= __('transfer_to') ?></p>
                    <?php endif; ?>

                    <ul style="margin: 10px 0 10px 20px;">
                        <li>Bank BNU: <b><?= htmlspecialchars($SETTINGS['no_rek_bnu'] ?? '-') ?></b></li>
                        <li>Bank BNCTL: <b><?= htmlspecialchars($SETTINGS['no_rek_bnctl'] ?? '-') ?></b></li>
                        <li>Bank Mandiri: <b><?= htmlspecialchars($SETTINGS['no_rek_mandiri'] ?? '-') ?></b></li>
                    </ul>
                    <p style="margin-top: 10px; color: #d32f2f;"><b><?= __('important') ?>:</b> <?= __('pending_msg') ?></p>
                </div>

                <a href="upload_bukti.php?kode=<?= $kode_booking ?>" class="btn-primary" style="display: inline-block; width: 100%; padding: 15px; margin-top: 20px; text-decoration: none; background: #ff9800; font-size: 16px; font-weight: bold; box-sizing: border-box;">
                    📤 Upload Bukti Transfer
                </a>

                <a href="pesan.php?lang=<?= $_SESSION['lang'] ?>" class="btn-primary" style="display: inline-block; width: auto; padding: 12px 30px; margin-top: 15px; text-decoration: none; background: #666;"><?= __('back_to_home') ?></a>
            </div>
        <?php endif; ?>

    </div>

    <!-- FOOTER DENGAN SYARAT & KETENTUAN -->
    <footer style="text-align: center; padding: 20px; font-size: 12px; color: var(--text); opacity: 0.8; border-top: 1px solid var(--border); margin-top: auto; width: 100%; box-sizing: border-box;">
        <p style="margin-bottom: 5px;">&copy; <?= date('Y') ?> <b><?= htmlspecialchars($SETTINGS['nama_perusahaan'] ?? 'APORTIL, I.P.') ?></b>. All Rights Reserved.</p>
        <p>
            <a href="syarat_ketentuan.php" style="color: var(--primary); font-weight: bold; text-decoration: none;">Syarat & Ketentuan</a> | 
            <a href="syarat_ketentuan.php" style="color: var(--primary); font-weight: bold; text-decoration: none;">Kebijakan Privasi</a>
        </p>
    </footer>

    <!-- FLOATING WHATSAPP BUTTON -->
    <a href="https://wa.me/<?= $wa_admin_clean ?>?text=Halo%20Admin%20<?= urlencode($SETTINGS['nama_perusahaan'] ?? 'APORTIL') ?>%2C%20saya%20butuh%20bantuan%20terkait%20pemesanan%20tiket." class="floating-wa" target="_blank" title="Hubungi Admin via WhatsApp">
        <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
            <path d="M16 2a14 14 0 0 0-12.1 21l-1.9 7 7.2-1.9A14 14 0 1 0 16 2zm0 25.4a11.3 11.3 0 0 1-5.8-1.6l-.4-.2-4.3 1.1 1.1-4.1-.3-.5a11.4 11.4 0 1 1 9.7 5.3zm6.3-8.5c-.3-.2-2.1-1-2.4-1.1s-.6-.2-.8.2-1 1.2-1.2 1.4-.4.3-.8.1a9.1 9.1 0 0 1-2.7-1.7 10.1 10.1 0 0 1-1.9-2.3c-.2-.3 0-.5.1-.7s.5-.6.7-.8a3.2 3.2 0 0 0 .5-.8.9.9 0 0 0 0-.9c-.1-.2-.8-2-1.1-2.7s-.6-.6-.8-.6h-.7a1.4 1.4 0 0 0-1 .5 5.9 5.9 0 0 0-1.8 4.4 10.2 10.2 0 0 0 2.1 5.4c.3.4 3.6 5.5 8.7 7.7a18.6 18.6 0 0 0 2.9.9 7 7 0 0 0 3.2-.2 4.8 4.8 0 0 0 1.6-1.1 3.4 3.4 0 0 0 .7-1.5c.1-.3.1-.5 0-.6s-.2-.2-.5-.3z"/>
        </svg>
    </a>

    <!-- LEAFLET MAP JS & LOCATE PLUGIN -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/leaflet.locatecontrol@0.79.0/dist/L.Control.Locate.min.js"></script>
    
    <script>
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            if (document.body.classList.contains('dark-mode')) {
                localStorage.setItem('theme', 'dark');
                document.getElementById('theme-btn').innerText = '☀️';
            } else {
                localStorage.setItem('theme', 'light');
                document.getElementById('theme-btn').innerText = '🌙';
            }
        }

        window.addEventListener('DOMContentLoaded', () => {
            if (document.body.classList.contains('dark-mode')) {
                document.getElementById('theme-btn').innerText = '☀️';
            }
        });

        <?php if ($step == 1): ?>
        // === INISIALISASI PETA PINTAR ===
        var map = L.map('map').setView([-8.55, 125.57], 9);

        // 1. Layer Peta Standar (OpenStreetMap)
        var standardMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 18, attribution: '© OpenStreetMap'
        });

        // 2. Layer Peta Satelit (Esri World Imagery)
        var satelliteMap = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            maxZoom: 18, attribution: '© Esri, Maxar, Earthstar Geographics'
        });

        // Tambahkan default layer ke peta
        standardMap.addTo(map);

        // Buat Kontrol Layer (Tombol ganti Standar/Satelit)
        var baseMaps = {
            "🗺️ Peta Jalan": standardMap,
            "🛰️ Satelit": satelliteMap
        };
        L.control.layers(baseMaps, null, { position: 'topright' }).addTo(map);

        // 3. Fitur GPS Lokasi Pengguna (Titik Biru)
        L.control.locate({
            position: 'topright',
            flyTo: true,
            strings: { title: "Tampilkan Lokasi Saya" }
        }).addTo(map);

        // 4. Tampilkan Marker Pelabuhan
        var pelabuhanData = <?= json_encode($map_data) ?>;
        var portCoordinates = {}; 

        pelabuhanData.forEach(function(p) {
            portCoordinates[p.nama] = [p.latitude, p.longitude];
            L.marker([p.latitude, p.longitude]).addTo(map).bindPopup('<b>⚓ ' + p.nama + '</b><br>Pelabuhan');
        });

        // 5. Gambar Garis Rute & Estimasi Waktu
        // Cek jika data Dili ada
        if(portCoordinates['Dili']) {
            var diliPos = portCoordinates['Dili'];

            // Rute ke Atauro
            if(portCoordinates['Atauro']) {
                L.polyline([diliPos, portCoordinates['Atauro']], {
                    color: 'blue', weight: 3, opacity: 0.7, dashArray: '10, 10'
                }).addTo(map).bindPopup('<b>Rute Dili ➔ Atauro</b><br>Estimasi: ± 2 - 3 Jam');
            }

            // Rute ke Oecusse
            if(portCoordinates['Oecusse']) {
                L.polyline([diliPos, portCoordinates['Oecusse']], {
                    color: 'green', weight: 3, opacity: 0.7, dashArray: '10, 10'
                }).addTo(map).bindPopup('<b>Rute Dili ➔ Oecusse</b><br>Estimasi: ± 12 - 14 Jam');
            }
        }
        <?php endif; ?>
    </script>
</body>
</html>
