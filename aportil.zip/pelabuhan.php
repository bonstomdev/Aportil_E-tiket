<?php
require_once 'config.php';
checkAuth();
checkAdmin();

$msg = '';
$edit_mode = false;
$data_edit = ['id' => '', 'nama' => '', 'latitude' => '', 'longitude' => ''];

// Tangkap data jika tombol EDIT diklik
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $id = (int)$_GET['edit'];
    $stmt = $mysqli->prepare("SELECT * FROM pelabuhan WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $data_edit = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Proses Tambah / Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['tambah']) || isset($_POST['update']))) {
    verifyCsrfToken($_POST['csrf_token']);
    $nama = trim($_POST['nama']);
    $lat = trim($_POST['latitude']);
    $lng = trim($_POST['longitude']);

    if ($nama !== '' && $lat !== '' && $lng !== '') {
        if (isset($_POST['update'])) {
            $id = (int)$_POST['id'];
            $stmt = $mysqli->prepare("UPDATE pelabuhan SET nama=?, latitude=?, longitude=? WHERE id=?");
            $stmt->bind_param('ssdi', $nama, $lat, $lng, $id);
            $stmt->execute();
            $msg = "<div class='alert-success'>✅ Pelabuhan <b>$nama</b> berhasil diperbarui!</div>";
            catatLog("Edit Pelabuhan", "Pelabuhan: $nama");
        } else {
            $stmt = $mysqli->prepare("INSERT INTO pelabuhan (nama, latitude, longitude) VALUES (?, ?, ?)");
            $stmt->bind_param('sdd', $nama, $lat, $lng);
            $stmt->execute();
            $msg = "<div class='alert-success'>✅ Pelabuhan <b>$nama</b> berhasil ditambahkan!</div>";
            catatLog("Tambah Pelabuhan", "Pelabuhan: $nama");
        }
        $stmt->close();
        $edit_mode = false;
    } else {
        $msg = "<div class='alert-error'>❌ Harap isi semua kolom dengan benar!</div>";
    }
}

// Proses Hapus
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $stmt = $mysqli->prepare("SELECT nama FROM pelabuhan WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $p = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($p) {
        $stmt = $mysqli->prepare("DELETE FROM pelabuhan WHERE id = ?");
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) {
            $msg = "<div class='alert-error'>🗑️ Pelabuhan <b>" . htmlspecialchars($p['nama']) . "</b> berhasil dihapus!</div>";
            catatLog("Hapus Pelabuhan", "Pelabuhan: " . $p['nama']);
        }
        $stmt->close();
    }
}

$result = $mysqli->query("SELECT * FROM pelabuhan ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Pelabuhan - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= ucfirst($_SESSION['role']) ?>)</span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="pelabuhan.php" class="active">⚓ Master Pelabuhan</a>
            <a href="kapal.php">⚓ Master Pelabuhan
            <a href="kapal.php">🚢 Master Kapal</a></a>
            <a href="rute.php">🗺️ Master Rute</a>
            <a href="voyage.php">⏰ Jadwal Voyage</a>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <a href="laporan.php">📑 Laporan</a>
            <a href="z_report.php">🧾 Z-Report Kasir</a>
            <a href="voucher.php">🎟️ Voucher Promo</a>
            <a href="profil.php">🏢 Profil Perusahaan</a>
            <a href="users.php">👥 Manajemen Pegawai</a>
            <a href="log.php">🕵️‍♂️ Log Aktivitas</a>
            <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
            <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
        </div>

        <div class="main-content">
            <h2>Manajemen Pelabuhan</h2>
            <p>Kelola data pelabuhan, termasuk koordinat untuk peta interaktif.</p>
            
            <?= $msg ?>

            <div class="card">
                <h3><?= $edit_mode ? 'Edit Data Pelabuhan' : 'Tambah Pelabuhan Baru' ?></h3>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <?php if($edit_mode): ?>
                        <input type="hidden" name="id" value="<?= $data_edit['id'] ?>">
                    <?php endif; ?>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Nama Pelabuhan</label>
                            <input type="text" name="nama" placeholder="Misal: Suai" value="<?= htmlspecialchars($data_edit['nama'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Latitude (Garis Lintang)</label>
                            <input type="text" name="latitude" placeholder="Misal: -9.312" value="<?= htmlspecialchars($data_edit['latitude'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Longitude (Garis Bujur)</label>
                            <input type="text" name="longitude" placeholder="Misal: 125.256" value="<?= htmlspecialchars($data_edit['longitude'] ?? '') ?>" required>
                        </div>
                    </div>
                    
                    <?php if($edit_mode): ?>
                        <button type="submit" name="update" class="btn-primary" style="width: auto; padding: 10px 20px; background: #e65100;">💾 Simpan Perubahan</button>
                        <a href="pelabuhan.php" class="btn-primary" style="width: auto; padding: 10px 20px; background: #666; text-decoration: none; display: inline-block;">Batal</a>
                    <?php else: ?>
                        <button type="submit" name="tambah" class="btn-primary" style="width: auto; padding: 10px 20px;">+ Simpan Pelabuhan</button>
                    <?php endif; ?>
                </form>
            </div>

            <div class="card" style="margin-top: 20px;">
                <h3>Daftar Pelabuhan</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Pelabuhan</th>
                                <th>Koordinat (Lat, Lng)</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no=1; while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><b><?= htmlspecialchars($row['nama']) ?></b></td>
                                <td style="font-family: monospace;"><?= htmlspecialchars($row['latitude']) ?>, <?= htmlspecialchars($row['longitude']) ?></td>
                                <td style="white-space: nowrap;">
                                    <a href="?edit=<?= $row['id'] ?>" class="btn-primary" style="background: #f57c00; padding: 6px 12px; font-size: 12px; display: inline-block; width: auto; text-decoration: none;">✏️ Edit</a>
                                    <a href="?hapus=<?= $row['id'] ?>" class="btn-danger" onclick="return confirm('Yakin ingin menghapus pelabuhan ini?')">🗑️ Hapus</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</body>
</html>
