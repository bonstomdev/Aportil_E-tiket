<?php
require_once 'config.php';
require_once 'negara.php'; 
checkAuth(); // Bisa diakses Admin & Kasir

$msg = '';

// PROSES SIMPAN TIKET LOKET
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['jual_loket'])) {
    verifyCsrfToken($_POST['csrf_token']);
    
    $voyage_id = (int)$_POST['voyage_id'];
    $nama_pemesan = trim($_POST['nama_pemesan']);
    $no_hp = trim($_POST['no_hp'] ?? '-');
    $kelas = $_POST['kelas'];
    $jenis_kendaraan = $_POST['jenis_kendaraan'];
    $plat_nomor = trim($_POST['plat_nomor']);
    $jumlah_kargo = (int)$_POST['jumlah_kargo'];
    $deskripsi_kargo = trim($_POST['deskripsi_kargo'] ?? '');
    
    $nama_penumpangs = $_POST['nama_penumpang'] ?? [];
    $no_identitas_arr = $_POST['no_identitas'] ?? [];
    $negara_arr = $_POST['negara'] ?? [];
    $jumlah_pax = count($nama_penumpangs);

    // Ambil harga voyage
    $sql = "SELECT v.*, t.harga_ekonomi, t.harga_bisnis, t.harga_motor, t.harga_mobil, t.harga_kargo 
            FROM voyage v 
            JOIN tarif t ON v.pelabuhan_asal_id = t.pelabuhan_asal_id AND v.pelabuhan_tujuan_id = t.pelabuhan_tujuan_id
            WHERE v.id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('i', $voyage_id);
    $stmt->execute();
    $v = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($v && $jumlah_pax > 0) {
        $harga_tiket = ($kelas == 'Bisnis') ? $v['harga_bisnis'] : $v['harga_ekonomi'];
        $total_awal = ($harga_tiket * $jumlah_pax);
        if ($jenis_kendaraan == 'Motor') $total_awal += $v['harga_motor'];
        if ($jenis_kendaraan == 'Mobil') $total_awal += $v['harga_mobil'];
        $total_awal += ($v['harga_kargo'] * $jumlah_kargo);

        $kode = 'APT-LKT-' . date('ymd') . '-' . strtoupper(substr(uniqid(), -4));

        // Langsung simpan dengan status PAID (Lunas di loket)
        $stmt = $mysqli->prepare("INSERT INTO booking (kode_booking, voyage_id, nama_pemesan, no_hp, total_bayar, status, metode_bayar) VALUES (?, ?, ?, ?, ?, 'Paid', 'loket')");
        $stmt->bind_param('sissd', $kode, $voyage_id, $nama_pemesan, $no_hp, $total_awal);
        $stmt->execute();
        $booking_id = $mysqli->insert_id;
        $stmt->close();

        for ($i = 0; $i < $jumlah_pax; $i++) {
            $nm = trim($nama_penumpangs[$i]);
            $id_num = trim($no_identitas_arr[$i]);
            $negara = trim($negara_arr[$i] ?? 'Timor-Leste');
            
            $stmt2 = $mysqli->prepare("INSERT INTO tiket (booking_id, nama_penumpang, no_identitas, negara, kelas, jenis_kendaraan, plat_nomor, jumlah_kargo, deskripsi_kargo, harga_tiket) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt2->bind_param('issssssiss', $booking_id, $nm, $id_num, $negara, $kelas, $jenis_kendaraan, $plat_nomor, $jumlah_kargo, $deskripsi_kargo, $harga_tiket);
            $stmt2->execute();
            $stmt2->close();
        }

        catatLog("Jual Loket", "Tiket $kode terjual di loket");
        
        // Redirect langsung ke halaman cetak tiket
        header("Location: tiket.php?kode=" . $kode);
        exit;
    }
}

// Ambil daftar voyage hari ini dan ke depan
$hari_ini = date('Y-m-d');
$sql_v = "SELECT v.*, k.nama_kapal, p1.nama as asal, p2.nama as tujuan, t.harga_ekonomi, t.harga_bisnis, t.harga_motor, t.harga_mobil, t.harga_kargo 
          FROM voyage v 
          JOIN kapal k ON v.kapal_id = k.id 
          JOIN pelabuhan p1 ON v.pelabuhan_asal_id = p1.id 
          JOIN pelabuhan p2 ON v.pelabuhan_tujuan_id = p2.id 
          JOIN tarif t ON v.pelabuhan_asal_id = t.pelabuhan_asal_id AND v.pelabuhan_tujuan_id = t.pelabuhan_tujuan_id
          WHERE v.tanggal >= '$hari_ini' 
          ORDER BY v.tanggal ASC, v.jam_berangkat ASC";
$result_v = $mysqli->query($sql_v);
$voyages = [];
while($rv = $result_v->fetch_assoc()) { $voyages[] = $rv; }
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jual Tiket Loket - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Kasir</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?> (<?= ucfirst($_SESSION['role'] ?? 'kasir') ?>)</span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <?php if(($_SESSION['role'] ?? '') == 'admin'): ?>
                <a href="pelabuhan.php">⚓ Master Pelabuhan</a>
                <a href="kapal.php">🚢 Master Kapal</a>
                <a href="rute.php">🗺️ Master Rute</a>
                <a href="voyage.php">⏰ Jadwal Voyage</a>
            <?php endif; ?>
            <a href="loket.php" class="active" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <?php if(($_SESSION['role'] ?? '') == 'admin'): ?>
                <a href="laporan.php">📑 Laporan</a>
                <a href="z_report.php">🧾 Z-Report Kasir</a>
                <a href="voucher.php">🎟️ Voucher Promo</a>
                <a href="profil.php">🏢 Profil Perusahaan</a>
                <a href="users.php">👥 Manajemen Pegawai</a>
                <a href="log.php">🕵️‍♂️ Log Aktivitas</a>
                <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
                <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
            <?php endif; ?>
        </div>

        <div class="main-content">
            <h2>Jual Tiket Langsung (Loket)</h2>
            <p>Layani pembelian tiket tunai di loket. Tiket akan otomatis LUNAS (PAID) dan siap dicetak.</p>

            <div class="card" style="border-left: 5px solid #2e7d32;">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    
                    <div class="form-group">
                        <label>Pilih Jadwal Keberangkatan</label>
                        <select name="voyage_id" id="voyageSelect" required onchange="updateHarga()">
                            <option value="">-- Pilih Jadwal Kapal --</option>
                            <?php foreach($voyages as $v): ?>
                                <option value="<?= $v['id'] ?>" 
                                        data-eko="<?= $v['harga_ekonomi'] ?>" 
                                        data-bis="<?= $v['harga_bisnis'] ?>"
                                        data-motor="<?= $v['harga_motor'] ?>"
                                        data-mobil="<?= $v['harga_mobil'] ?>"
                                        data-kargo="<?= $v['harga_kargo'] ?>">
                                    <?= date('d M Y', strtotime($v['tanggal'])) ?> | <?= date('H:i', strtotime($v['jam_berangkat'])) ?> - <?= htmlspecialchars($v['nama_kapal']) ?> (<?= htmlspecialchars($v['asal']) ?> ➔ <?= htmlspecialchars($v['tujuan']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Nama Pemesan (Untuk Struk)</label>
                            <input type="text" name="nama_pemesan" required>
                        </div>
                        <div class="form-group">
                            <label>No. HP/WA (Opsional)</label>
                            <input type="text" name="no_hp" placeholder="-">
                        </div>
                        <div class="form-group">
                            <label>Kelas</label>
                            <select name="kelas" required onchange="updateHarga()" id="kelasSelect">
                                <option value="Ekonomi">Ekonomi</option>
                                <option value="Bisnis">Bisnis</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Jumlah Penumpang</label>
                            <input type="number" name="jumlah_pax" id="jumlah_pax" value="1" min="1" max="20" onchange="generateForms()" required>
                        </div>
                    </div>

                    <div id="passenger-inputs" style="background: #f9f9f9; padding: 15px; border-radius: 8px; margin-bottom: 15px; border: 1px solid #ddd;"></div>

                    <h4 style="margin: 15px 0 10px 0;">Tambahan (Opsional)</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Kendaraan</label>
                            <select name="jenis_kendaraan" id="kendaraanSelect" onchange="updateHarga()">
                                <option value="Tidak Ada" data-harga="0">Tidak Ada</option>
                                <option value="Motor">Motor</option>
                                <option value="Mobil">Mobil</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Plat Nomor</label>
                            <input type="text" name="plat_nomor" placeholder="-">
                        </div>
                        <div class="form-group">
                            <label>Kargo / Koli</label>
                            <input type="number" name="jumlah_kargo" id="kargoInput" value="0" min="0" onchange="updateHarga()">
                        </div>
                        <div class="form-group">
                            <label>Deskripsi Kargo</label>
                            <input type="text" name="deskripsi_kargo" placeholder="-">
                        </div>
                    </div>

                    <div class="alert-success" style="margin-top: 15px; font-size: 20px; font-weight: bold; text-align: center;">
                        Total Bayar (Tunai): <span id="total_harga">$0.00</span> USD
                    </div>

                    <button type="submit" name="jual_loket" class="btn-primary" style="margin-top: 15px; background: #2e7d32; font-size: 18px; padding: 15px;">
                        💾 Proses & Cetak Tiket
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        const daftarNegara = <?= json_encode($daftar_negara) ?>;
        
        function generateForms() {
            let count = parseInt(document.getElementById('jumlah_pax').value) || 1;
            let container = document.getElementById('passenger-inputs');
            container.innerHTML = '';
            
            let negaraOptions = '';
            daftarNegara.forEach(function(n) {
                negaraOptions += `<option value="${n}" ${n === 'Timor-Leste' ? 'selected' : ''}>${n}</option>`;
            });
            
            for(let i=1; i<=count; i++) {
                container.innerHTML += `
                    <div style="background: #fff; padding: 10px; border-radius: 5px; margin-bottom: 10px; border-left: 3px solid #0B2E6F;">
                        <h5 style="margin-bottom: 5px; font-size: 13px;">Penumpang ${i}</h5>
                        <div class="form-row" style="margin-bottom: 5px;">
                            <div class="form-group">
                                <label>Nama Lengkap</label>
                                <input type="text" name="nama_penumpang[]" required>
                            </div>
                            <div class="form-group">
                                <label>No. Identitas (KTP/Passport)</label>
                                <input type="text" name="no_identitas[]" required>
                            </div>
                            <div class="form-group">
                                <label>Negara</label>
                                <select name="negara[]">${negaraOptions}</select>
                            </div>
                        </div>
                    </div>
                `;
            }
            updateHarga();
        }

        function updateHarga() {
            let vSelect = document.getElementById('voyageSelect');
            let kSelect = document.getElementById('kelasSelect');
            let kendaraan = document.getElementById('kendaraanSelect');
            let kargo = document.getElementById('kargoInput');
            let jumlahPax = document.getElementById('jumlah_pax');

            if(!vSelect.value) return;
            
            let opt = vSelect.options[vSelect.selectedIndex];
            let hargaTiket = (kSelect.value == 'Bisnis') ? parseFloat(opt.dataset.bis) : parseFloat(opt.dataset.eko);
            let hargaKargo = parseFloat(opt.dataset.kargo);
            
            let hargaKendaraan = 0;
            if(kendaraan.value == 'Motor') hargaKendaraan = parseFloat(opt.dataset.motor);
            if(kendaraan.value == 'Mobil') hargaKendaraan = parseFloat(opt.dataset.mobil);
            
            let total = (hargaTiket * parseInt(jumlahPax.value || 1)) + hargaKendaraan + (hargaKargo * parseInt(kargo.value || 0));
            
            document.getElementById('total_harga').innerText = '$' + total.toFixed(2);
        }

        // Panggil saat pertama load
        generateForms();
    </script>
</body>
</html>
