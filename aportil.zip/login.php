<?php
require_once 'config.php';

if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $stmt = $mysqli->prepare("SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($user) {
            if (password_verify($password, $user['password'])) {
                $login_success = true;
            } elseif ($user['password'] === $password) {
                $login_success = true;
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $upd = $mysqli->prepare("UPDATE users SET password = ? WHERE id = ?");
                $upd->bind_param('si', $newHash, $user['id']);
                $upd->execute();
                $upd->close();
            } else {
                $login_success = false;
            }

            if (isset($login_success) && $login_success) {
                session_regenerate_id(true); 
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                catatLog("Login", "Berhasil masuk ke sistem");
                header('Location: index.php');
                exit;
            }
        }
        sleep(1);
        $error = "Username atau Password salah!";
    } else {
        $error = "Harap isi username dan password.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - APORTIL Ferry</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="login-page">
    <div class="login-box glass-effect">
        <h1>⚓ APORTIL</h1>
        <p>Sistem Informasi Tiket Feri</p>
        
        <?php if ($error): ?>
            <div class="alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="Masukkan username" required autocomplete="off">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Masukkan password" required>
            </div>
            <button type="submit" class="btn-primary">Masuk Sistem</button>
        </form>
        
        <div style="margin-top: 20px; display: flex; flex-direction: column; gap: 10px;">
            <a href="lupa_password.php" style="color: #ffcc00; font-size: 13px; text-decoration: none; font-weight: bold;">Lupa Password?</a>
            <a href="pesan.php" style="color: #fff; font-size: 13px; text-decoration: none; opacity: 0.8;">← Kembali ke Halaman Penumpang</a>
        </div>
    </div>
</body>
</html>
