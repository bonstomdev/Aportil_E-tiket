<?php
require_once 'config.php';

// Memaksa sistem untuk mereset ke admin / admin123
$hash = password_hash('admin123', PASSWORD_DEFAULT);
$mysqli->query("UPDATE users SET username='admin', password='$hash' WHERE id=1");

echo "<div style='text-align:center; margin-top:50px; font-family:sans-serif;'>";
echo "<h1 style='color:#2e7d32;'>✅ BERHASIL DI-RESET!</h1>";
echo "<p>Username telah dikembalikan ke: <b>admin</b></p>";
echo "<p>Password telah dikembalikan ke: <b>admin123</b></p>";
echo "<br><a href='login.php' style='padding:10px 20px; background:#0B2E6F; color:white; text-decoration:none; border-radius:5px;'>Ke Halaman Login</a>";
echo "</div>";
?>
