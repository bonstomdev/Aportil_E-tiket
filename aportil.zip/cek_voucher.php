<?php
require_once 'config.php';

$kode = strtoupper(trim($_POST['kode'] ?? ''));
$total_awal = (float)($_POST['total_awal'] ?? 0);

if (!$kode) {
    echo json_encode(['ok' => false, 'msg' => 'Masukkan kode voucher.']);
    exit;
}

$stmt = $mysqli->prepare("SELECT * FROM voucher WHERE kode = ? AND status = 'aktif'");
$stmt->bind_param('s', $kode);
$stmt->execute();
$v = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$v) {
    echo json_encode(['ok' => false, 'msg' => 'Kode voucher tidak valid / sudah tidak aktif.']);
    exit;
}

if ($v['kuota'] > 0 && $v['terpakai'] >= $v['kuota']) {
    echo json_encode(['ok' => false, 'msg' => 'Kuota voucher ini sudah habis.']);
    exit;
}

// Hitung diskon
$diskon = 0;
if ($v['tipe'] == 'nominal') {
    $diskon = $v['nilai'];
} else {
    $diskon = ($v['nilai'] / 100) * $total_awal;
}

if ($diskon > $total_awal) {
    $diskon = $total_awal; // Diskon tidak boleh melebihi total harga
}

echo json_encode([
    'ok' => true, 
    'diskon' => $diskon, 
    'voucher_id' => $v['id'], 
    'msg' => 'Voucher berhasil diterapkan! Potongan: $' . number_format($diskon, 2)
]);
?>
