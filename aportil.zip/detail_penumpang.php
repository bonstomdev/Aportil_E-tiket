<?php
require_once 'config.php';
checkAuth();

$booking_id = (int)($_GET['id'] ?? 0);

$stmt = $mysqli->prepare("SELECT b.*, v.kode_voyage, k.nama_kapal FROM booking b JOIN voyage v ON b.voyage_id = v.id JOIN kapal k ON v.kapal_id = k.id WHERE b.id = ?");
$stmt->bind_param('i', $booking_id);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    die("<h2 style='text-align:center; margin-top:50px;'>Data Booking tidak ditemukan.</h2>");
}

$stmt2 = $mysqli->prepare("SELECT * FROM tiket WHERE booking_id = ?");
$stmt2->bind_param('i', $booking_id);
$stmt2->execute();
$penumpangs = $stmt2->get_result();
$stmt2->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Penumpang - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background: var(--bg);">
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <a href="verifikasi.php" class="btn-logout">← Kembali</a>
        </div>
    </nav>

    <div style="max-width: 900px; margin: 20px auto; padding: 20px;">
        <div class="card">
            <h2 style="color: var(--primary);">👥 Detail Penumpang</h2>
            <p><b>Kode Booking:</b> <?= htmlspecialchars($booking['kode_booking']) ?></p>
            <p><b>Voyage:</b> <?= htmlspecialchars($booking['kode_voyage']) ?> - <?= htmlspecialchars($booking['nama_kapal']) ?></p>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 15px;">
            <?php $no=1; while($p = $penumpangs->fetch_assoc()): ?>
                <div class="card">
                    <h4 style="color: var(--primary); border-bottom: 2px solid var(--border); padding-bottom: 5px;">Penumpang <?= $no++ ?></h4>
                    <p style="margin: 8px 0;"><b>Nama:</b><br><?= htmlspecialchars($p['nama_penumpang']) ?></p>
                    <p style="margin: 8px 0;"><b>No. Identitas:</b><br><?= htmlspecialchars($p['no_identitas']) ?></p>
                    <p style="margin: 8px 0;"><b>Negara:</b><br>🌍 <?= htmlspecialchars($p['negara'] ?? 'Timor-Leste') ?></p>
                    <p style="margin: 8px 0;"><b>Kelas:</b> <?= $p['kelas'] ?></p>
                    
                    <?php if(!empty($p['foto_identitas'])): ?>
                        <div style="margin-top: 10px;">
                            <b>Foto Identitas:</b><br>
                            <a href="uploads/<?= htmlspecialchars($p['foto_identitas']) ?>" target="_blank">
                                <img src="uploads/<?= htmlspecialchars($p['foto_identitas']) ?>" style="max-width: 100%; border-radius: 8px; border: 2px solid var(--border); margin-top: 5px;">
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="alert-error" style="margin-top: 10px; font-size: 12px;">⚠️ Penumpang belum upload foto identitas</div>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>
