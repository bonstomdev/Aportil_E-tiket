<?php
require_once 'config.php';
checkAuth(); checkAdmin(); checkAdmin();

// Default filter hari ini
$tgl_mulai = $_GET['tgl_mulai'] ?? date('Y-m-d');
$tgl_selesai = $_GET['tgl_selesai'] ?? date('Y-m-d');

$sql = "SELECT b.*, t.nama_penumpang, t.kelas, v.kode_voyage, k.nama_kapal, p1.nama as asal, p2.nama as tujuan
        FROM booking b
        JOIN tiket t ON b.id = t.booking_id
        JOIN voyage v ON b.voyage_id = v.id
        JOIN kapal k ON v.kapal_id = k.id
        JOIN pelabuhan p1 ON v.pelabuhan_asal_id = p1.id
        JOIN pelabuhan p2 ON v.pelabuhan_tujuan_id = p2.id
        WHERE b.status = 'Paid' AND DATE(b.created_at) BETWEEN ? AND ?
        ORDER BY b.created_at DESC";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param('ss', $tgl_mulai, $tgl_selesai);
$stmt->execute();
$result = $stmt->get_result();

$total_pendapatan = 0;
$total_tiket = 0;
$data_laporan = [];
while($row = $result->fetch_assoc()) {
    $total_pendapatan += $row['total_bayar'];
    $total_tiket++;
    $data_laporan[] = $row;
}
$stmt->close();

// === FITUR EXPORT CSV (EXCEL) ===
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $filename = "Laporan_APORTIL_" . $tgl_mulai . "_sd_" . $tgl_selesai . ".csv";
    
    // Set header untuk memaksa browser mendownload file
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    
    // Tambahkan BOM (Byte Order Mark) agar Excel bisa membaca karakter UTF-8 (seperti é, ç, dll) dengan benar
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Buat Header Kolom di Excel
    fputcsv($output, ['No', 'Kode Booking', 'Tgl Transaksi', 'Nama Penumpang', 'Rute', 'Kapal', 'Voyage', 'Kelas', 'Total (USD)']);
    
    // Isi Data
    $no = 1;
    foreach ($data_laporan as $row) {
        fputcsv($output, [
            $no++,
            $row['kode_booking'],
            date('d/m/Y H:i', strtotime($row['created_at'])),
            $row['nama_penumpang'],
            $row['asal'] . ' - ' . $row['tujuan'],
            $row['nama_kapal'],
            $row['kode_voyage'],
            $row['kelas'],
            $row['total_bayar']
        ]);
    }
    
    // Baris Total di bawah
    fputcsv($output, ['', '', '', '', '', '', '', 'TOTAL PENDAPATAN', $total_pendapatan]);
    
    fclose($output);
    exit;
}
// =================================
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pendapatan - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">⚓ APORTIL Admin</div>
        <div class="user-info">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="sidebar">
            <a href="index.php">📊 Dasbor</a>
            <a href="kapal.php">⚓ Master Pelabuhan
            <a href="kapal.php">🚢 Master Kapal</a></a>
            <a href="rute.php">🗺️ Master Rute</a>
            <a href="voyage.php">⏰ Jadwal Voyage</a>
            <a href="loket.php" style="background: #e8f5e9; color: #2e7d32; font-weight: bold;">🛒 Jual Tiket (Loket)</a>
            <a href="verifikasi.php">📥 Verifikasi Tiket</a>
            <a href="cari_penumpang.php">🔍 Cari Penumpang</a>
            <a href="scan.php">📷 Scan QR</a>
            <a href="laporan.php" class="active">📑 Laporan
            <a href="z_report.php">🧾 Z-Report Kasir
            <a href="voucher.php">🎟️ Voucher Promo</a>
            <a href="profil.php">🏢 Profil Perusahaan</a></a></a>
            <a href="ganti_password.php">⚙️ Pengaturan Akun</a>
            <a href="backup.php" style="color: #d32f2f; font-weight: bold;">💾 Backup Database</a>
        </div>

        <div class="main-content">
            <h2>Laporan Pendapatan</h2>
            <p>Laporan tiket yang sudah dibayar (PAID).</p>
            
            <div class="card">
                <form method="GET" class="form-row" style="align-items: flex-end;">
                    <div class="form-group">
                        <label>Dari Tanggal</label>
                        <input type="date" name="tgl_mulai" value="<?= $tgl_mulai ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Sampai Tanggal</label>
                        <input type="date" name="tgl_selesai" value="<?= $tgl_selesai ?>" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn-primary" style="padding: 12px;">🔍 Tampilkan</button>
                    </div>
                    <div class="form-group">
                        <button type="button" onclick="window.print()" class="btn-primary" style="padding: 12px; background: #0d47a1;">🖨️ Cetak Laporan</button>
                    </div>
                    <div class="form-group">
                        <!-- TOMBOL EXPORT EXCEL BARU -->
                        <a href="?export=csv&tgl_mulai=<?= $tgl_mulai ?>&tgl_selesai=<?= $tgl_selesai ?>" class="btn-primary" style="padding: 12px; background: #2e7d32; text-decoration: none; display: inline-block; text-align: center;">📊 Download Excel (CSV)</a>
                    </div>
                </form>
            </div>

            <div class="card" id="area-cetak">
                <div style="text-align: center; margin-bottom: 20px;">
                    <h3 style="margin: 0; font-size: 20px;">APORTIL, I.P.</h3>
                    <p style="margin: 5px 0;">Laporan Pendapatan Tiket Feri</p>
                    <p style="margin: 0; font-size: 14px;">Periode: <?= date('d M Y', strtotime($tgl_mulai)) ?> s/d <?= date('d M Y', strtotime($tgl_selesai)) ?></p>
                </div>

                <div class="alert-success" style="display: flex; justify-content: space-between; font-size: 18px; margin-bottom: 20px;">
                    <span>Total Transaksi: <b><?= $total_tiket ?></b> Tiket</span>
                    <span>Total Pendapatan: <b>$<?= number_format($total_pendapatan, 2) ?> USD</b></span>
                </div>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Tgl & Kode</th>
                                <th>Nama Penumpang</th>
                                <th>Rute & Kapal</th>
                                <th>Kelas</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($data_laporan) > 0): ?>
                                <?php foreach($data_laporan as $row): ?>
                                <tr>
                                    <td>
                                        <?= date('d/m/y', strtotime($row['created_at'])) ?><br>
                                        <small style="color: #666;"><?= htmlspecialchars($row['kode_booking']) ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($row['nama_penumpang']) ?></td>
                                    <td>
                                        <?= htmlspecialchars($row['asal']) ?> ➔ <?= htmlspecialchars($row['tujuan']) ?><br>
                                        <small style="color: #666;"><?= htmlspecialchars($row['nama_kapal']) ?> (<?= $row['kode_voyage'] ?>)</small>
                                    </td>
                                    <td><?= $row['kelas'] ?></td>
                                    <td>$<?= number_format($row['total_bayar'], 2) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="5" style="text-align:center;">Tidak ada transaksi pada periode ini.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <style>
        @media print {
            .navbar, .sidebar, .card form, .main-content > p, .main-content > h2 { display: none !important; }
            .dashboard-container { display: block; }
            .main-content { padding: 0; }
            .card { box-shadow: none; border: none; padding: 0; }
            body { background: white; }
        }
    </style>
</body>
</html>
