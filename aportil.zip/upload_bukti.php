<?php
require_once 'config.php';

$kode = $_GET['kode'] ?? '';
$msg = '';

if (!$kode) {
    die("<h2 style='text-align:center; margin-top:50px;'>Kode Booking tidak valid.</h2>");
}

// Ambil data booking
$stmt = $mysqli->prepare("SELECT id, status, bukti_transfer FROM booking WHERE kode_booking = ?");
$stmt->bind_param('s', $kode);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    die("<h2 style='text-align:center; margin-top:50px;'>Data Booking tidak ditemukan.</h2>");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['bukti'])) {
    $file = $_FILES['bukti'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png'];

    if (!in_array($ext, $allowed)) {
        $msg = "<div class='alert-error'>❌ Format file harus JPG, JPEG, atau PNG.</div>";
    } elseif ($file['size'] > 2 * 1024 * 1024) { // Maksimal 2MB
        $msg = "<div class='alert-error'>❌ Ukuran file maksimal 2MB.</div>";
    } else {
        $new_name = 'bukti_' . $kode . '_' . time() . '.' . $ext;
        $target = 'uploads/' . $new_name;

        if (move_uploaded_file($file['tmp_name'], $target)) {
            $upd = $mysqli->prepare("UPDATE booking SET bukti_transfer = ? WHERE id = ?");
            $upd->bind_param('si', $new_name, $booking['id']);
            $upd->execute();
            $upd->close();

            $msg = "<div class='alert-success'>✅ Bukti transfer berhasil di-upload! Admin akan segera memverifikasi pesanan Anda.</div>";
            $booking['bukti_transfer'] = $new_name;
        } else {
            $msg = "<div class='alert-error'>❌ Gagal mengunggah file. Coba lagi.</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Bukti Transfer - APORTIL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background: #eef1f7;">
    <div style="max-width: 500px; margin: 50px auto; padding: 20px;">
        <div class="card" style="text-align: center;">
            <h2 style="color: #0B2E6F; margin-bottom: 5px;">📤 Upload Bukti Transfer</h2>
            <p style="color: #666; margin-bottom: 20px; font-size: 14px;">Kode Booking: <b><?= htmlspecialchars($kode) ?></b></p>
            
            <?= $msg ?>

            <?php if ($booking['bukti_transfer']): ?>
                <div class="alert-success" style="margin-bottom: 15px;">Anda sudah meng-upload bukti transfer sebelumnya. Jika ingin mengganti, silakan upload ulang di bawah.</div>
                <img src="uploads/<?= htmlspecialchars($booking['bukti_transfer']) ?>" style="max-width: 100%; border-radius: 8px; margin-bottom: 15px; border: 1px solid #ddd;">
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Pilih Foto Bukti Transfer (JPG/PNG, Maks 2MB)</label>
                    <input type="file" name="bukti" required accept="image/jpeg, image/png" style="padding: 10px; border: 1px dashed #0B2E6F; border-radius: 8px; width: 100%;">
                </div>
                <button type="submit" class="btn-primary">Upload Sekarang</button>
            </form>
            
            <div style="margin-top: 20px;">
                <a href="cek_tiket.php" style="color: #0B2E6F; font-size: 13px; text-decoration: none; font-weight: bold;">← Cek Status Tiket</a>
            </div>
        </div>
    </div>
</body>
</html>
